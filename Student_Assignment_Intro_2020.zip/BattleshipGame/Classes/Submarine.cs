﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BattleshipGame.Classes
{
    public class Submarine
    {
        public int shipSize { get; set; }
        public Submarine()
        {
            this.shipSize = 3;
        }
    }
}
