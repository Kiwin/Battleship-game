﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BattleshipGame.Classes
{
    public class Cruiser
    {
        public int shipSize { get; set; }
        public Cruiser()
        {
            this.shipSize = 3;
        }
    }
}
