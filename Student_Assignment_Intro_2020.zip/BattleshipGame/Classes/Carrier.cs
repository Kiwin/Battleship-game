﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BattleshipGame.Classes
{
    public class Carrier
    {
        public int shipSize { get; set; }
        public Carrier()
        {
            this.shipSize = 3;
        }
    }
}
