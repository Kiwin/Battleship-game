﻿namespace BattleshipGame
{
    partial class GameWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.player1SecretGridGroupBox = new System.Windows.Forms.GroupBox();
            this.button100 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button97 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.newGameBtn = new System.Windows.Forms.Button();
            this.endTurnBtn = new System.Windows.Forms.Button();
            this.debugLabel = new System.Windows.Forms.Label();
            this.player2SecretGridGroupBox = new System.Windows.Forms.GroupBox();
            this.button101 = new System.Windows.Forms.Button();
            this.button102 = new System.Windows.Forms.Button();
            this.button103 = new System.Windows.Forms.Button();
            this.button104 = new System.Windows.Forms.Button();
            this.button105 = new System.Windows.Forms.Button();
            this.button106 = new System.Windows.Forms.Button();
            this.button107 = new System.Windows.Forms.Button();
            this.button108 = new System.Windows.Forms.Button();
            this.button109 = new System.Windows.Forms.Button();
            this.button110 = new System.Windows.Forms.Button();
            this.button111 = new System.Windows.Forms.Button();
            this.button112 = new System.Windows.Forms.Button();
            this.button113 = new System.Windows.Forms.Button();
            this.button114 = new System.Windows.Forms.Button();
            this.button115 = new System.Windows.Forms.Button();
            this.button116 = new System.Windows.Forms.Button();
            this.button117 = new System.Windows.Forms.Button();
            this.button118 = new System.Windows.Forms.Button();
            this.button119 = new System.Windows.Forms.Button();
            this.button120 = new System.Windows.Forms.Button();
            this.button121 = new System.Windows.Forms.Button();
            this.button122 = new System.Windows.Forms.Button();
            this.button123 = new System.Windows.Forms.Button();
            this.button124 = new System.Windows.Forms.Button();
            this.button125 = new System.Windows.Forms.Button();
            this.button126 = new System.Windows.Forms.Button();
            this.button127 = new System.Windows.Forms.Button();
            this.button128 = new System.Windows.Forms.Button();
            this.button129 = new System.Windows.Forms.Button();
            this.button130 = new System.Windows.Forms.Button();
            this.button131 = new System.Windows.Forms.Button();
            this.button132 = new System.Windows.Forms.Button();
            this.button133 = new System.Windows.Forms.Button();
            this.button134 = new System.Windows.Forms.Button();
            this.button135 = new System.Windows.Forms.Button();
            this.button136 = new System.Windows.Forms.Button();
            this.button137 = new System.Windows.Forms.Button();
            this.button138 = new System.Windows.Forms.Button();
            this.button139 = new System.Windows.Forms.Button();
            this.button140 = new System.Windows.Forms.Button();
            this.button141 = new System.Windows.Forms.Button();
            this.button142 = new System.Windows.Forms.Button();
            this.button143 = new System.Windows.Forms.Button();
            this.button144 = new System.Windows.Forms.Button();
            this.button145 = new System.Windows.Forms.Button();
            this.button146 = new System.Windows.Forms.Button();
            this.button147 = new System.Windows.Forms.Button();
            this.button148 = new System.Windows.Forms.Button();
            this.button149 = new System.Windows.Forms.Button();
            this.button150 = new System.Windows.Forms.Button();
            this.button151 = new System.Windows.Forms.Button();
            this.button152 = new System.Windows.Forms.Button();
            this.button153 = new System.Windows.Forms.Button();
            this.button154 = new System.Windows.Forms.Button();
            this.button155 = new System.Windows.Forms.Button();
            this.button156 = new System.Windows.Forms.Button();
            this.button157 = new System.Windows.Forms.Button();
            this.button158 = new System.Windows.Forms.Button();
            this.button159 = new System.Windows.Forms.Button();
            this.button160 = new System.Windows.Forms.Button();
            this.button161 = new System.Windows.Forms.Button();
            this.button162 = new System.Windows.Forms.Button();
            this.button163 = new System.Windows.Forms.Button();
            this.button164 = new System.Windows.Forms.Button();
            this.button165 = new System.Windows.Forms.Button();
            this.button166 = new System.Windows.Forms.Button();
            this.button167 = new System.Windows.Forms.Button();
            this.button168 = new System.Windows.Forms.Button();
            this.button169 = new System.Windows.Forms.Button();
            this.button170 = new System.Windows.Forms.Button();
            this.button171 = new System.Windows.Forms.Button();
            this.button172 = new System.Windows.Forms.Button();
            this.button173 = new System.Windows.Forms.Button();
            this.button174 = new System.Windows.Forms.Button();
            this.button175 = new System.Windows.Forms.Button();
            this.button176 = new System.Windows.Forms.Button();
            this.button177 = new System.Windows.Forms.Button();
            this.button178 = new System.Windows.Forms.Button();
            this.button179 = new System.Windows.Forms.Button();
            this.button180 = new System.Windows.Forms.Button();
            this.button181 = new System.Windows.Forms.Button();
            this.button182 = new System.Windows.Forms.Button();
            this.button183 = new System.Windows.Forms.Button();
            this.button184 = new System.Windows.Forms.Button();
            this.button185 = new System.Windows.Forms.Button();
            this.button186 = new System.Windows.Forms.Button();
            this.button187 = new System.Windows.Forms.Button();
            this.button188 = new System.Windows.Forms.Button();
            this.button189 = new System.Windows.Forms.Button();
            this.button190 = new System.Windows.Forms.Button();
            this.button191 = new System.Windows.Forms.Button();
            this.button192 = new System.Windows.Forms.Button();
            this.button193 = new System.Windows.Forms.Button();
            this.button194 = new System.Windows.Forms.Button();
            this.button195 = new System.Windows.Forms.Button();
            this.button196 = new System.Windows.Forms.Button();
            this.button197 = new System.Windows.Forms.Button();
            this.button198 = new System.Windows.Forms.Button();
            this.button199 = new System.Windows.Forms.Button();
            this.button200 = new System.Windows.Forms.Button();
            this.player1PublicGridGroupBox = new System.Windows.Forms.GroupBox();
            this.button201 = new System.Windows.Forms.Button();
            this.button202 = new System.Windows.Forms.Button();
            this.button203 = new System.Windows.Forms.Button();
            this.button204 = new System.Windows.Forms.Button();
            this.button205 = new System.Windows.Forms.Button();
            this.button206 = new System.Windows.Forms.Button();
            this.button207 = new System.Windows.Forms.Button();
            this.button208 = new System.Windows.Forms.Button();
            this.button209 = new System.Windows.Forms.Button();
            this.button210 = new System.Windows.Forms.Button();
            this.button211 = new System.Windows.Forms.Button();
            this.button212 = new System.Windows.Forms.Button();
            this.button213 = new System.Windows.Forms.Button();
            this.button214 = new System.Windows.Forms.Button();
            this.button215 = new System.Windows.Forms.Button();
            this.button216 = new System.Windows.Forms.Button();
            this.button217 = new System.Windows.Forms.Button();
            this.button218 = new System.Windows.Forms.Button();
            this.button219 = new System.Windows.Forms.Button();
            this.button220 = new System.Windows.Forms.Button();
            this.button221 = new System.Windows.Forms.Button();
            this.button222 = new System.Windows.Forms.Button();
            this.button223 = new System.Windows.Forms.Button();
            this.button224 = new System.Windows.Forms.Button();
            this.button225 = new System.Windows.Forms.Button();
            this.button226 = new System.Windows.Forms.Button();
            this.button227 = new System.Windows.Forms.Button();
            this.button228 = new System.Windows.Forms.Button();
            this.button229 = new System.Windows.Forms.Button();
            this.button230 = new System.Windows.Forms.Button();
            this.button231 = new System.Windows.Forms.Button();
            this.button232 = new System.Windows.Forms.Button();
            this.button233 = new System.Windows.Forms.Button();
            this.button234 = new System.Windows.Forms.Button();
            this.button235 = new System.Windows.Forms.Button();
            this.button236 = new System.Windows.Forms.Button();
            this.button237 = new System.Windows.Forms.Button();
            this.button238 = new System.Windows.Forms.Button();
            this.button239 = new System.Windows.Forms.Button();
            this.button240 = new System.Windows.Forms.Button();
            this.button241 = new System.Windows.Forms.Button();
            this.button242 = new System.Windows.Forms.Button();
            this.button243 = new System.Windows.Forms.Button();
            this.button244 = new System.Windows.Forms.Button();
            this.button245 = new System.Windows.Forms.Button();
            this.button246 = new System.Windows.Forms.Button();
            this.button247 = new System.Windows.Forms.Button();
            this.button248 = new System.Windows.Forms.Button();
            this.button249 = new System.Windows.Forms.Button();
            this.button250 = new System.Windows.Forms.Button();
            this.button251 = new System.Windows.Forms.Button();
            this.button252 = new System.Windows.Forms.Button();
            this.button253 = new System.Windows.Forms.Button();
            this.button254 = new System.Windows.Forms.Button();
            this.button255 = new System.Windows.Forms.Button();
            this.button256 = new System.Windows.Forms.Button();
            this.button257 = new System.Windows.Forms.Button();
            this.button258 = new System.Windows.Forms.Button();
            this.button259 = new System.Windows.Forms.Button();
            this.button260 = new System.Windows.Forms.Button();
            this.button261 = new System.Windows.Forms.Button();
            this.button262 = new System.Windows.Forms.Button();
            this.button263 = new System.Windows.Forms.Button();
            this.button264 = new System.Windows.Forms.Button();
            this.button265 = new System.Windows.Forms.Button();
            this.button266 = new System.Windows.Forms.Button();
            this.button267 = new System.Windows.Forms.Button();
            this.button268 = new System.Windows.Forms.Button();
            this.button269 = new System.Windows.Forms.Button();
            this.button270 = new System.Windows.Forms.Button();
            this.button271 = new System.Windows.Forms.Button();
            this.button272 = new System.Windows.Forms.Button();
            this.button273 = new System.Windows.Forms.Button();
            this.button274 = new System.Windows.Forms.Button();
            this.button275 = new System.Windows.Forms.Button();
            this.button276 = new System.Windows.Forms.Button();
            this.button277 = new System.Windows.Forms.Button();
            this.button278 = new System.Windows.Forms.Button();
            this.button279 = new System.Windows.Forms.Button();
            this.button280 = new System.Windows.Forms.Button();
            this.button281 = new System.Windows.Forms.Button();
            this.button282 = new System.Windows.Forms.Button();
            this.button283 = new System.Windows.Forms.Button();
            this.button284 = new System.Windows.Forms.Button();
            this.button285 = new System.Windows.Forms.Button();
            this.button286 = new System.Windows.Forms.Button();
            this.button287 = new System.Windows.Forms.Button();
            this.button288 = new System.Windows.Forms.Button();
            this.button289 = new System.Windows.Forms.Button();
            this.button290 = new System.Windows.Forms.Button();
            this.button291 = new System.Windows.Forms.Button();
            this.button292 = new System.Windows.Forms.Button();
            this.button293 = new System.Windows.Forms.Button();
            this.button294 = new System.Windows.Forms.Button();
            this.button295 = new System.Windows.Forms.Button();
            this.button296 = new System.Windows.Forms.Button();
            this.button297 = new System.Windows.Forms.Button();
            this.button298 = new System.Windows.Forms.Button();
            this.button299 = new System.Windows.Forms.Button();
            this.button300 = new System.Windows.Forms.Button();
            this.player2PublicGridGroupBox = new System.Windows.Forms.GroupBox();
            this.button301 = new System.Windows.Forms.Button();
            this.button302 = new System.Windows.Forms.Button();
            this.button303 = new System.Windows.Forms.Button();
            this.button304 = new System.Windows.Forms.Button();
            this.button305 = new System.Windows.Forms.Button();
            this.button306 = new System.Windows.Forms.Button();
            this.button307 = new System.Windows.Forms.Button();
            this.button308 = new System.Windows.Forms.Button();
            this.button309 = new System.Windows.Forms.Button();
            this.button310 = new System.Windows.Forms.Button();
            this.button311 = new System.Windows.Forms.Button();
            this.button312 = new System.Windows.Forms.Button();
            this.button313 = new System.Windows.Forms.Button();
            this.button314 = new System.Windows.Forms.Button();
            this.button315 = new System.Windows.Forms.Button();
            this.button316 = new System.Windows.Forms.Button();
            this.button317 = new System.Windows.Forms.Button();
            this.button318 = new System.Windows.Forms.Button();
            this.button319 = new System.Windows.Forms.Button();
            this.button320 = new System.Windows.Forms.Button();
            this.button321 = new System.Windows.Forms.Button();
            this.button322 = new System.Windows.Forms.Button();
            this.button323 = new System.Windows.Forms.Button();
            this.button324 = new System.Windows.Forms.Button();
            this.button325 = new System.Windows.Forms.Button();
            this.button326 = new System.Windows.Forms.Button();
            this.button327 = new System.Windows.Forms.Button();
            this.button328 = new System.Windows.Forms.Button();
            this.button329 = new System.Windows.Forms.Button();
            this.button330 = new System.Windows.Forms.Button();
            this.button331 = new System.Windows.Forms.Button();
            this.button332 = new System.Windows.Forms.Button();
            this.button333 = new System.Windows.Forms.Button();
            this.button334 = new System.Windows.Forms.Button();
            this.button335 = new System.Windows.Forms.Button();
            this.button336 = new System.Windows.Forms.Button();
            this.button337 = new System.Windows.Forms.Button();
            this.button338 = new System.Windows.Forms.Button();
            this.button339 = new System.Windows.Forms.Button();
            this.button340 = new System.Windows.Forms.Button();
            this.button341 = new System.Windows.Forms.Button();
            this.button342 = new System.Windows.Forms.Button();
            this.button343 = new System.Windows.Forms.Button();
            this.button344 = new System.Windows.Forms.Button();
            this.button345 = new System.Windows.Forms.Button();
            this.button346 = new System.Windows.Forms.Button();
            this.button347 = new System.Windows.Forms.Button();
            this.button348 = new System.Windows.Forms.Button();
            this.button349 = new System.Windows.Forms.Button();
            this.button350 = new System.Windows.Forms.Button();
            this.button351 = new System.Windows.Forms.Button();
            this.button352 = new System.Windows.Forms.Button();
            this.button353 = new System.Windows.Forms.Button();
            this.button354 = new System.Windows.Forms.Button();
            this.button355 = new System.Windows.Forms.Button();
            this.button356 = new System.Windows.Forms.Button();
            this.button357 = new System.Windows.Forms.Button();
            this.button358 = new System.Windows.Forms.Button();
            this.button359 = new System.Windows.Forms.Button();
            this.button360 = new System.Windows.Forms.Button();
            this.button361 = new System.Windows.Forms.Button();
            this.button362 = new System.Windows.Forms.Button();
            this.button363 = new System.Windows.Forms.Button();
            this.button364 = new System.Windows.Forms.Button();
            this.button365 = new System.Windows.Forms.Button();
            this.button366 = new System.Windows.Forms.Button();
            this.button367 = new System.Windows.Forms.Button();
            this.button368 = new System.Windows.Forms.Button();
            this.button369 = new System.Windows.Forms.Button();
            this.button370 = new System.Windows.Forms.Button();
            this.button371 = new System.Windows.Forms.Button();
            this.button372 = new System.Windows.Forms.Button();
            this.button373 = new System.Windows.Forms.Button();
            this.button374 = new System.Windows.Forms.Button();
            this.button375 = new System.Windows.Forms.Button();
            this.button376 = new System.Windows.Forms.Button();
            this.button377 = new System.Windows.Forms.Button();
            this.button378 = new System.Windows.Forms.Button();
            this.button379 = new System.Windows.Forms.Button();
            this.button380 = new System.Windows.Forms.Button();
            this.button381 = new System.Windows.Forms.Button();
            this.button382 = new System.Windows.Forms.Button();
            this.button383 = new System.Windows.Forms.Button();
            this.button384 = new System.Windows.Forms.Button();
            this.button385 = new System.Windows.Forms.Button();
            this.button386 = new System.Windows.Forms.Button();
            this.button387 = new System.Windows.Forms.Button();
            this.button388 = new System.Windows.Forms.Button();
            this.button389 = new System.Windows.Forms.Button();
            this.button390 = new System.Windows.Forms.Button();
            this.button391 = new System.Windows.Forms.Button();
            this.button392 = new System.Windows.Forms.Button();
            this.button393 = new System.Windows.Forms.Button();
            this.button394 = new System.Windows.Forms.Button();
            this.button395 = new System.Windows.Forms.Button();
            this.button396 = new System.Windows.Forms.Button();
            this.button397 = new System.Windows.Forms.Button();
            this.button398 = new System.Windows.Forms.Button();
            this.button399 = new System.Windows.Forms.Button();
            this.button400 = new System.Windows.Forms.Button();
            this.player1SecretGridGroupBox.SuspendLayout();
            this.player2SecretGridGroupBox.SuspendLayout();
            this.player1PublicGridGroupBox.SuspendLayout();
            this.player2PublicGridGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // player1SecretGridGroupBox
            // 
            this.player1SecretGridGroupBox.Controls.Add(this.button100);
            this.player1SecretGridGroupBox.Controls.Add(this.button99);
            this.player1SecretGridGroupBox.Controls.Add(this.button98);
            this.player1SecretGridGroupBox.Controls.Add(this.button97);
            this.player1SecretGridGroupBox.Controls.Add(this.button96);
            this.player1SecretGridGroupBox.Controls.Add(this.button95);
            this.player1SecretGridGroupBox.Controls.Add(this.button94);
            this.player1SecretGridGroupBox.Controls.Add(this.button93);
            this.player1SecretGridGroupBox.Controls.Add(this.button92);
            this.player1SecretGridGroupBox.Controls.Add(this.button91);
            this.player1SecretGridGroupBox.Controls.Add(this.button90);
            this.player1SecretGridGroupBox.Controls.Add(this.button89);
            this.player1SecretGridGroupBox.Controls.Add(this.button88);
            this.player1SecretGridGroupBox.Controls.Add(this.button87);
            this.player1SecretGridGroupBox.Controls.Add(this.button86);
            this.player1SecretGridGroupBox.Controls.Add(this.button85);
            this.player1SecretGridGroupBox.Controls.Add(this.button84);
            this.player1SecretGridGroupBox.Controls.Add(this.button83);
            this.player1SecretGridGroupBox.Controls.Add(this.button82);
            this.player1SecretGridGroupBox.Controls.Add(this.button81);
            this.player1SecretGridGroupBox.Controls.Add(this.button80);
            this.player1SecretGridGroupBox.Controls.Add(this.button79);
            this.player1SecretGridGroupBox.Controls.Add(this.button78);
            this.player1SecretGridGroupBox.Controls.Add(this.button77);
            this.player1SecretGridGroupBox.Controls.Add(this.button76);
            this.player1SecretGridGroupBox.Controls.Add(this.button75);
            this.player1SecretGridGroupBox.Controls.Add(this.button74);
            this.player1SecretGridGroupBox.Controls.Add(this.button73);
            this.player1SecretGridGroupBox.Controls.Add(this.button72);
            this.player1SecretGridGroupBox.Controls.Add(this.button71);
            this.player1SecretGridGroupBox.Controls.Add(this.button70);
            this.player1SecretGridGroupBox.Controls.Add(this.button69);
            this.player1SecretGridGroupBox.Controls.Add(this.button68);
            this.player1SecretGridGroupBox.Controls.Add(this.button67);
            this.player1SecretGridGroupBox.Controls.Add(this.button66);
            this.player1SecretGridGroupBox.Controls.Add(this.button65);
            this.player1SecretGridGroupBox.Controls.Add(this.button64);
            this.player1SecretGridGroupBox.Controls.Add(this.button63);
            this.player1SecretGridGroupBox.Controls.Add(this.button62);
            this.player1SecretGridGroupBox.Controls.Add(this.button61);
            this.player1SecretGridGroupBox.Controls.Add(this.button60);
            this.player1SecretGridGroupBox.Controls.Add(this.button59);
            this.player1SecretGridGroupBox.Controls.Add(this.button58);
            this.player1SecretGridGroupBox.Controls.Add(this.button57);
            this.player1SecretGridGroupBox.Controls.Add(this.button56);
            this.player1SecretGridGroupBox.Controls.Add(this.button55);
            this.player1SecretGridGroupBox.Controls.Add(this.button54);
            this.player1SecretGridGroupBox.Controls.Add(this.button53);
            this.player1SecretGridGroupBox.Controls.Add(this.button52);
            this.player1SecretGridGroupBox.Controls.Add(this.button51);
            this.player1SecretGridGroupBox.Controls.Add(this.button50);
            this.player1SecretGridGroupBox.Controls.Add(this.button49);
            this.player1SecretGridGroupBox.Controls.Add(this.button48);
            this.player1SecretGridGroupBox.Controls.Add(this.button47);
            this.player1SecretGridGroupBox.Controls.Add(this.button46);
            this.player1SecretGridGroupBox.Controls.Add(this.button45);
            this.player1SecretGridGroupBox.Controls.Add(this.button44);
            this.player1SecretGridGroupBox.Controls.Add(this.button43);
            this.player1SecretGridGroupBox.Controls.Add(this.button42);
            this.player1SecretGridGroupBox.Controls.Add(this.button41);
            this.player1SecretGridGroupBox.Controls.Add(this.button40);
            this.player1SecretGridGroupBox.Controls.Add(this.button39);
            this.player1SecretGridGroupBox.Controls.Add(this.button38);
            this.player1SecretGridGroupBox.Controls.Add(this.button37);
            this.player1SecretGridGroupBox.Controls.Add(this.button36);
            this.player1SecretGridGroupBox.Controls.Add(this.button35);
            this.player1SecretGridGroupBox.Controls.Add(this.button34);
            this.player1SecretGridGroupBox.Controls.Add(this.button33);
            this.player1SecretGridGroupBox.Controls.Add(this.button32);
            this.player1SecretGridGroupBox.Controls.Add(this.button31);
            this.player1SecretGridGroupBox.Controls.Add(this.button30);
            this.player1SecretGridGroupBox.Controls.Add(this.button29);
            this.player1SecretGridGroupBox.Controls.Add(this.button28);
            this.player1SecretGridGroupBox.Controls.Add(this.button27);
            this.player1SecretGridGroupBox.Controls.Add(this.button26);
            this.player1SecretGridGroupBox.Controls.Add(this.button25);
            this.player1SecretGridGroupBox.Controls.Add(this.button24);
            this.player1SecretGridGroupBox.Controls.Add(this.button23);
            this.player1SecretGridGroupBox.Controls.Add(this.button22);
            this.player1SecretGridGroupBox.Controls.Add(this.button21);
            this.player1SecretGridGroupBox.Controls.Add(this.button20);
            this.player1SecretGridGroupBox.Controls.Add(this.button19);
            this.player1SecretGridGroupBox.Controls.Add(this.button18);
            this.player1SecretGridGroupBox.Controls.Add(this.button17);
            this.player1SecretGridGroupBox.Controls.Add(this.button16);
            this.player1SecretGridGroupBox.Controls.Add(this.button15);
            this.player1SecretGridGroupBox.Controls.Add(this.button14);
            this.player1SecretGridGroupBox.Controls.Add(this.button13);
            this.player1SecretGridGroupBox.Controls.Add(this.button12);
            this.player1SecretGridGroupBox.Controls.Add(this.button11);
            this.player1SecretGridGroupBox.Controls.Add(this.button10);
            this.player1SecretGridGroupBox.Controls.Add(this.button9);
            this.player1SecretGridGroupBox.Controls.Add(this.button8);
            this.player1SecretGridGroupBox.Controls.Add(this.button7);
            this.player1SecretGridGroupBox.Controls.Add(this.button6);
            this.player1SecretGridGroupBox.Controls.Add(this.button5);
            this.player1SecretGridGroupBox.Controls.Add(this.button4);
            this.player1SecretGridGroupBox.Controls.Add(this.button3);
            this.player1SecretGridGroupBox.Controls.Add(this.button2);
            this.player1SecretGridGroupBox.Controls.Add(this.button1);
            this.player1SecretGridGroupBox.Location = new System.Drawing.Point(12, 4);
            this.player1SecretGridGroupBox.Name = "player1SecretGridGroupBox";
            this.player1SecretGridGroupBox.Size = new System.Drawing.Size(467, 451);
            this.player1SecretGridGroupBox.TabIndex = 0;
            this.player1SecretGridGroupBox.TabStop = false;
            this.player1SecretGridGroupBox.Text = "Player 1";
            // 
            // button100
            // 
            this.button100.Location = new System.Drawing.Point(420, 406);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(40, 37);
            this.button100.TabIndex = 99;
            this.button100.UseVisualStyleBackColor = true;
            // 
            // button99
            // 
            this.button99.Location = new System.Drawing.Point(374, 406);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(40, 37);
            this.button99.TabIndex = 98;
            this.button99.UseVisualStyleBackColor = true;
            // 
            // button98
            // 
            this.button98.Location = new System.Drawing.Point(328, 406);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(40, 37);
            this.button98.TabIndex = 97;
            this.button98.UseVisualStyleBackColor = true;
            // 
            // button97
            // 
            this.button97.Location = new System.Drawing.Point(282, 406);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(40, 37);
            this.button97.TabIndex = 96;
            this.button97.UseVisualStyleBackColor = true;
            // 
            // button96
            // 
            this.button96.Location = new System.Drawing.Point(236, 406);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(40, 37);
            this.button96.TabIndex = 95;
            this.button96.UseVisualStyleBackColor = true;
            // 
            // button95
            // 
            this.button95.Location = new System.Drawing.Point(190, 406);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(40, 37);
            this.button95.TabIndex = 94;
            this.button95.UseVisualStyleBackColor = true;
            // 
            // button94
            // 
            this.button94.Location = new System.Drawing.Point(144, 406);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(40, 37);
            this.button94.TabIndex = 93;
            this.button94.UseVisualStyleBackColor = true;
            // 
            // button93
            // 
            this.button93.Location = new System.Drawing.Point(98, 406);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(40, 37);
            this.button93.TabIndex = 92;
            this.button93.UseVisualStyleBackColor = true;
            // 
            // button92
            // 
            this.button92.Location = new System.Drawing.Point(52, 406);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(40, 37);
            this.button92.TabIndex = 91;
            this.button92.UseVisualStyleBackColor = true;
            // 
            // button91
            // 
            this.button91.Location = new System.Drawing.Point(6, 406);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(40, 37);
            this.button91.TabIndex = 90;
            this.button91.UseVisualStyleBackColor = true;
            // 
            // button90
            // 
            this.button90.Location = new System.Drawing.Point(420, 363);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(40, 37);
            this.button90.TabIndex = 89;
            this.button90.UseVisualStyleBackColor = true;
            // 
            // button89
            // 
            this.button89.Location = new System.Drawing.Point(374, 363);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(40, 37);
            this.button89.TabIndex = 88;
            this.button89.UseVisualStyleBackColor = true;
            // 
            // button88
            // 
            this.button88.Location = new System.Drawing.Point(328, 363);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(40, 37);
            this.button88.TabIndex = 87;
            this.button88.UseVisualStyleBackColor = true;
            // 
            // button87
            // 
            this.button87.Location = new System.Drawing.Point(282, 363);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(40, 37);
            this.button87.TabIndex = 86;
            this.button87.UseVisualStyleBackColor = true;
            // 
            // button86
            // 
            this.button86.Location = new System.Drawing.Point(236, 363);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(40, 37);
            this.button86.TabIndex = 85;
            this.button86.UseVisualStyleBackColor = true;
            // 
            // button85
            // 
            this.button85.Location = new System.Drawing.Point(190, 363);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(40, 37);
            this.button85.TabIndex = 84;
            this.button85.UseVisualStyleBackColor = true;
            // 
            // button84
            // 
            this.button84.Location = new System.Drawing.Point(144, 363);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(40, 37);
            this.button84.TabIndex = 83;
            this.button84.UseVisualStyleBackColor = true;
            // 
            // button83
            // 
            this.button83.Location = new System.Drawing.Point(98, 363);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(40, 37);
            this.button83.TabIndex = 82;
            this.button83.UseVisualStyleBackColor = true;
            // 
            // button82
            // 
            this.button82.Location = new System.Drawing.Point(52, 363);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(40, 37);
            this.button82.TabIndex = 81;
            this.button82.UseVisualStyleBackColor = true;
            // 
            // button81
            // 
            this.button81.Location = new System.Drawing.Point(6, 363);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(40, 37);
            this.button81.TabIndex = 80;
            this.button81.UseVisualStyleBackColor = true;
            // 
            // button80
            // 
            this.button80.Location = new System.Drawing.Point(420, 320);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(40, 37);
            this.button80.TabIndex = 79;
            this.button80.UseVisualStyleBackColor = true;
            // 
            // button79
            // 
            this.button79.Location = new System.Drawing.Point(374, 320);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(40, 37);
            this.button79.TabIndex = 78;
            this.button79.UseVisualStyleBackColor = true;
            // 
            // button78
            // 
            this.button78.Location = new System.Drawing.Point(328, 320);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(40, 37);
            this.button78.TabIndex = 77;
            this.button78.UseVisualStyleBackColor = true;
            // 
            // button77
            // 
            this.button77.Location = new System.Drawing.Point(282, 320);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(40, 37);
            this.button77.TabIndex = 76;
            this.button77.UseVisualStyleBackColor = true;
            // 
            // button76
            // 
            this.button76.Location = new System.Drawing.Point(236, 320);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(40, 37);
            this.button76.TabIndex = 75;
            this.button76.UseVisualStyleBackColor = true;
            // 
            // button75
            // 
            this.button75.Location = new System.Drawing.Point(190, 320);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(40, 37);
            this.button75.TabIndex = 74;
            this.button75.UseVisualStyleBackColor = true;
            // 
            // button74
            // 
            this.button74.Location = new System.Drawing.Point(144, 320);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(40, 37);
            this.button74.TabIndex = 73;
            this.button74.UseVisualStyleBackColor = true;
            // 
            // button73
            // 
            this.button73.Location = new System.Drawing.Point(98, 320);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(40, 37);
            this.button73.TabIndex = 72;
            this.button73.UseVisualStyleBackColor = true;
            // 
            // button72
            // 
            this.button72.Location = new System.Drawing.Point(52, 320);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(40, 37);
            this.button72.TabIndex = 71;
            this.button72.UseVisualStyleBackColor = true;
            // 
            // button71
            // 
            this.button71.Location = new System.Drawing.Point(6, 320);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(40, 37);
            this.button71.TabIndex = 70;
            this.button71.UseVisualStyleBackColor = true;
            // 
            // button70
            // 
            this.button70.Location = new System.Drawing.Point(420, 277);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(40, 37);
            this.button70.TabIndex = 69;
            this.button70.UseVisualStyleBackColor = true;
            // 
            // button69
            // 
            this.button69.Location = new System.Drawing.Point(374, 277);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(40, 37);
            this.button69.TabIndex = 68;
            this.button69.UseVisualStyleBackColor = true;
            // 
            // button68
            // 
            this.button68.Location = new System.Drawing.Point(328, 277);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(40, 37);
            this.button68.TabIndex = 67;
            this.button68.UseVisualStyleBackColor = true;
            // 
            // button67
            // 
            this.button67.Location = new System.Drawing.Point(282, 277);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(40, 37);
            this.button67.TabIndex = 66;
            this.button67.UseVisualStyleBackColor = true;
            // 
            // button66
            // 
            this.button66.Location = new System.Drawing.Point(236, 277);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(40, 37);
            this.button66.TabIndex = 65;
            this.button66.UseVisualStyleBackColor = true;
            // 
            // button65
            // 
            this.button65.Location = new System.Drawing.Point(190, 277);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(40, 37);
            this.button65.TabIndex = 64;
            this.button65.UseVisualStyleBackColor = true;
            // 
            // button64
            // 
            this.button64.Location = new System.Drawing.Point(144, 277);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(40, 37);
            this.button64.TabIndex = 63;
            this.button64.UseVisualStyleBackColor = true;
            // 
            // button63
            // 
            this.button63.Location = new System.Drawing.Point(98, 277);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(40, 37);
            this.button63.TabIndex = 62;
            this.button63.UseVisualStyleBackColor = true;
            // 
            // button62
            // 
            this.button62.Location = new System.Drawing.Point(52, 277);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(40, 37);
            this.button62.TabIndex = 61;
            this.button62.UseVisualStyleBackColor = true;
            // 
            // button61
            // 
            this.button61.Location = new System.Drawing.Point(6, 277);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(40, 37);
            this.button61.TabIndex = 60;
            this.button61.UseVisualStyleBackColor = true;
            // 
            // button60
            // 
            this.button60.Location = new System.Drawing.Point(420, 234);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(40, 37);
            this.button60.TabIndex = 59;
            this.button60.UseVisualStyleBackColor = true;
            // 
            // button59
            // 
            this.button59.Location = new System.Drawing.Point(374, 234);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(40, 37);
            this.button59.TabIndex = 58;
            this.button59.UseVisualStyleBackColor = true;
            // 
            // button58
            // 
            this.button58.Location = new System.Drawing.Point(328, 234);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(40, 37);
            this.button58.TabIndex = 57;
            this.button58.UseVisualStyleBackColor = true;
            // 
            // button57
            // 
            this.button57.Location = new System.Drawing.Point(282, 234);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(40, 37);
            this.button57.TabIndex = 56;
            this.button57.UseVisualStyleBackColor = true;
            // 
            // button56
            // 
            this.button56.Location = new System.Drawing.Point(236, 234);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(40, 37);
            this.button56.TabIndex = 55;
            this.button56.UseVisualStyleBackColor = true;
            // 
            // button55
            // 
            this.button55.Location = new System.Drawing.Point(190, 234);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(40, 37);
            this.button55.TabIndex = 54;
            this.button55.UseVisualStyleBackColor = true;
            // 
            // button54
            // 
            this.button54.Location = new System.Drawing.Point(144, 234);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(40, 37);
            this.button54.TabIndex = 53;
            this.button54.UseVisualStyleBackColor = true;
            // 
            // button53
            // 
            this.button53.Location = new System.Drawing.Point(98, 234);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(40, 37);
            this.button53.TabIndex = 52;
            this.button53.UseVisualStyleBackColor = true;
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(52, 234);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(40, 37);
            this.button52.TabIndex = 51;
            this.button52.UseVisualStyleBackColor = true;
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(6, 234);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(40, 37);
            this.button51.TabIndex = 50;
            this.button51.UseVisualStyleBackColor = true;
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(420, 192);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(40, 37);
            this.button50.TabIndex = 49;
            this.button50.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(374, 191);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(40, 37);
            this.button49.TabIndex = 48;
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(328, 191);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(40, 37);
            this.button48.TabIndex = 47;
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(282, 191);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(40, 37);
            this.button47.TabIndex = 46;
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(236, 191);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(40, 37);
            this.button46.TabIndex = 45;
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(190, 191);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(40, 37);
            this.button45.TabIndex = 44;
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(144, 191);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(40, 37);
            this.button44.TabIndex = 43;
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(98, 191);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(40, 37);
            this.button43.TabIndex = 42;
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(52, 191);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(40, 37);
            this.button42.TabIndex = 41;
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(6, 191);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(40, 37);
            this.button41.TabIndex = 40;
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(420, 149);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(40, 37);
            this.button40.TabIndex = 39;
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(374, 149);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(40, 37);
            this.button39.TabIndex = 38;
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(328, 149);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(40, 37);
            this.button38.TabIndex = 37;
            this.button38.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(282, 148);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(40, 37);
            this.button37.TabIndex = 36;
            this.button37.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(236, 149);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(40, 37);
            this.button36.TabIndex = 35;
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(190, 149);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(40, 37);
            this.button35.TabIndex = 34;
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(144, 148);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(40, 37);
            this.button34.TabIndex = 33;
            this.button34.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(98, 149);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(40, 37);
            this.button33.TabIndex = 32;
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(52, 149);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(40, 37);
            this.button32.TabIndex = 31;
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(6, 148);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(40, 37);
            this.button31.TabIndex = 30;
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(421, 105);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(40, 37);
            this.button30.TabIndex = 29;
            this.button30.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(374, 105);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(40, 37);
            this.button29.TabIndex = 28;
            this.button29.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(328, 105);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(40, 37);
            this.button28.TabIndex = 27;
            this.button28.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(282, 105);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(40, 37);
            this.button27.TabIndex = 26;
            this.button27.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(236, 105);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(40, 37);
            this.button26.TabIndex = 25;
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(190, 105);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(40, 37);
            this.button25.TabIndex = 24;
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(144, 105);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(40, 37);
            this.button24.TabIndex = 23;
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(98, 105);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(40, 37);
            this.button23.TabIndex = 22;
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(52, 105);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(40, 37);
            this.button22.TabIndex = 21;
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(6, 105);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(40, 37);
            this.button21.TabIndex = 20;
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(420, 62);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(40, 37);
            this.button20.TabIndex = 19;
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(374, 62);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(40, 37);
            this.button19.TabIndex = 18;
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(328, 62);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(40, 37);
            this.button18.TabIndex = 17;
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(282, 62);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(40, 37);
            this.button17.TabIndex = 16;
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(236, 62);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(40, 37);
            this.button16.TabIndex = 15;
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(190, 62);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(40, 37);
            this.button15.TabIndex = 14;
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(144, 62);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(40, 37);
            this.button14.TabIndex = 13;
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(98, 62);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(40, 37);
            this.button13.TabIndex = 12;
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(52, 62);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(40, 37);
            this.button12.TabIndex = 11;
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(6, 62);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(40, 37);
            this.button11.TabIndex = 10;
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(420, 19);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(40, 37);
            this.button10.TabIndex = 9;
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(374, 19);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(40, 37);
            this.button9.TabIndex = 8;
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(328, 19);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(40, 37);
            this.button8.TabIndex = 7;
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(282, 19);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(40, 37);
            this.button7.TabIndex = 6;
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(236, 19);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(40, 37);
            this.button6.TabIndex = 5;
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(190, 19);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(40, 37);
            this.button5.TabIndex = 4;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(144, 19);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(40, 37);
            this.button4.TabIndex = 3;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(98, 19);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(40, 37);
            this.button3.TabIndex = 2;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(52, 19);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(40, 37);
            this.button2.TabIndex = 1;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(6, 19);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(40, 37);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // newGameBtn
            // 
            this.newGameBtn.Location = new System.Drawing.Point(492, 27);
            this.newGameBtn.Name = "newGameBtn";
            this.newGameBtn.Size = new System.Drawing.Size(141, 39);
            this.newGameBtn.TabIndex = 1;
            this.newGameBtn.Text = "New Game";
            this.newGameBtn.UseVisualStyleBackColor = true;
            this.newGameBtn.Click += new System.EventHandler(this.newGameBtn_Click);
            // 
            // endTurnBtn
            // 
            this.endTurnBtn.Location = new System.Drawing.Point(492, 72);
            this.endTurnBtn.Name = "endTurnBtn";
            this.endTurnBtn.Size = new System.Drawing.Size(141, 39);
            this.endTurnBtn.TabIndex = 2;
            this.endTurnBtn.Text = "End Turn";
            this.endTurnBtn.UseVisualStyleBackColor = true;
            this.endTurnBtn.Click += new System.EventHandler(this.endTurnBtn_Click);
            // 
            // debugLabel
            // 
            this.debugLabel.AutoSize = true;
            this.debugLabel.Location = new System.Drawing.Point(513, 152);
            this.debugLabel.Name = "debugLabel";
            this.debugLabel.Size = new System.Drawing.Size(0, 13);
            this.debugLabel.TabIndex = 3;
            // 
            // player2SecretGridGroupBox
            // 
            this.player2SecretGridGroupBox.Controls.Add(this.player1PublicGridGroupBox);
            this.player2SecretGridGroupBox.Controls.Add(this.button101);
            this.player2SecretGridGroupBox.Controls.Add(this.button102);
            this.player2SecretGridGroupBox.Controls.Add(this.button103);
            this.player2SecretGridGroupBox.Controls.Add(this.button104);
            this.player2SecretGridGroupBox.Controls.Add(this.button105);
            this.player2SecretGridGroupBox.Controls.Add(this.button106);
            this.player2SecretGridGroupBox.Controls.Add(this.button107);
            this.player2SecretGridGroupBox.Controls.Add(this.button108);
            this.player2SecretGridGroupBox.Controls.Add(this.button109);
            this.player2SecretGridGroupBox.Controls.Add(this.button110);
            this.player2SecretGridGroupBox.Controls.Add(this.button111);
            this.player2SecretGridGroupBox.Controls.Add(this.button112);
            this.player2SecretGridGroupBox.Controls.Add(this.button113);
            this.player2SecretGridGroupBox.Controls.Add(this.button114);
            this.player2SecretGridGroupBox.Controls.Add(this.button115);
            this.player2SecretGridGroupBox.Controls.Add(this.button116);
            this.player2SecretGridGroupBox.Controls.Add(this.button117);
            this.player2SecretGridGroupBox.Controls.Add(this.button118);
            this.player2SecretGridGroupBox.Controls.Add(this.button119);
            this.player2SecretGridGroupBox.Controls.Add(this.button120);
            this.player2SecretGridGroupBox.Controls.Add(this.button121);
            this.player2SecretGridGroupBox.Controls.Add(this.button122);
            this.player2SecretGridGroupBox.Controls.Add(this.button123);
            this.player2SecretGridGroupBox.Controls.Add(this.button124);
            this.player2SecretGridGroupBox.Controls.Add(this.button125);
            this.player2SecretGridGroupBox.Controls.Add(this.button126);
            this.player2SecretGridGroupBox.Controls.Add(this.button127);
            this.player2SecretGridGroupBox.Controls.Add(this.button128);
            this.player2SecretGridGroupBox.Controls.Add(this.button129);
            this.player2SecretGridGroupBox.Controls.Add(this.button130);
            this.player2SecretGridGroupBox.Controls.Add(this.button131);
            this.player2SecretGridGroupBox.Controls.Add(this.button132);
            this.player2SecretGridGroupBox.Controls.Add(this.button133);
            this.player2SecretGridGroupBox.Controls.Add(this.button134);
            this.player2SecretGridGroupBox.Controls.Add(this.button135);
            this.player2SecretGridGroupBox.Controls.Add(this.button136);
            this.player2SecretGridGroupBox.Controls.Add(this.button137);
            this.player2SecretGridGroupBox.Controls.Add(this.button138);
            this.player2SecretGridGroupBox.Controls.Add(this.button139);
            this.player2SecretGridGroupBox.Controls.Add(this.button140);
            this.player2SecretGridGroupBox.Controls.Add(this.button141);
            this.player2SecretGridGroupBox.Controls.Add(this.button142);
            this.player2SecretGridGroupBox.Controls.Add(this.button143);
            this.player2SecretGridGroupBox.Controls.Add(this.button144);
            this.player2SecretGridGroupBox.Controls.Add(this.button145);
            this.player2SecretGridGroupBox.Controls.Add(this.button146);
            this.player2SecretGridGroupBox.Controls.Add(this.button147);
            this.player2SecretGridGroupBox.Controls.Add(this.button148);
            this.player2SecretGridGroupBox.Controls.Add(this.button149);
            this.player2SecretGridGroupBox.Controls.Add(this.button150);
            this.player2SecretGridGroupBox.Controls.Add(this.button151);
            this.player2SecretGridGroupBox.Controls.Add(this.button152);
            this.player2SecretGridGroupBox.Controls.Add(this.button153);
            this.player2SecretGridGroupBox.Controls.Add(this.button154);
            this.player2SecretGridGroupBox.Controls.Add(this.button155);
            this.player2SecretGridGroupBox.Controls.Add(this.button156);
            this.player2SecretGridGroupBox.Controls.Add(this.button157);
            this.player2SecretGridGroupBox.Controls.Add(this.button158);
            this.player2SecretGridGroupBox.Controls.Add(this.button159);
            this.player2SecretGridGroupBox.Controls.Add(this.button160);
            this.player2SecretGridGroupBox.Controls.Add(this.button161);
            this.player2SecretGridGroupBox.Controls.Add(this.button162);
            this.player2SecretGridGroupBox.Controls.Add(this.button163);
            this.player2SecretGridGroupBox.Controls.Add(this.button164);
            this.player2SecretGridGroupBox.Controls.Add(this.button165);
            this.player2SecretGridGroupBox.Controls.Add(this.button166);
            this.player2SecretGridGroupBox.Controls.Add(this.button167);
            this.player2SecretGridGroupBox.Controls.Add(this.button168);
            this.player2SecretGridGroupBox.Controls.Add(this.button169);
            this.player2SecretGridGroupBox.Controls.Add(this.button170);
            this.player2SecretGridGroupBox.Controls.Add(this.button171);
            this.player2SecretGridGroupBox.Controls.Add(this.button172);
            this.player2SecretGridGroupBox.Controls.Add(this.button173);
            this.player2SecretGridGroupBox.Controls.Add(this.button174);
            this.player2SecretGridGroupBox.Controls.Add(this.button175);
            this.player2SecretGridGroupBox.Controls.Add(this.button176);
            this.player2SecretGridGroupBox.Controls.Add(this.button177);
            this.player2SecretGridGroupBox.Controls.Add(this.button178);
            this.player2SecretGridGroupBox.Controls.Add(this.button179);
            this.player2SecretGridGroupBox.Controls.Add(this.button180);
            this.player2SecretGridGroupBox.Controls.Add(this.button181);
            this.player2SecretGridGroupBox.Controls.Add(this.button182);
            this.player2SecretGridGroupBox.Controls.Add(this.button183);
            this.player2SecretGridGroupBox.Controls.Add(this.button184);
            this.player2SecretGridGroupBox.Controls.Add(this.button185);
            this.player2SecretGridGroupBox.Controls.Add(this.button186);
            this.player2SecretGridGroupBox.Controls.Add(this.button187);
            this.player2SecretGridGroupBox.Controls.Add(this.button188);
            this.player2SecretGridGroupBox.Controls.Add(this.button189);
            this.player2SecretGridGroupBox.Controls.Add(this.button190);
            this.player2SecretGridGroupBox.Controls.Add(this.button191);
            this.player2SecretGridGroupBox.Controls.Add(this.button192);
            this.player2SecretGridGroupBox.Controls.Add(this.button193);
            this.player2SecretGridGroupBox.Controls.Add(this.button194);
            this.player2SecretGridGroupBox.Controls.Add(this.button195);
            this.player2SecretGridGroupBox.Controls.Add(this.button196);
            this.player2SecretGridGroupBox.Controls.Add(this.button197);
            this.player2SecretGridGroupBox.Controls.Add(this.button198);
            this.player2SecretGridGroupBox.Controls.Add(this.button199);
            this.player2SecretGridGroupBox.Controls.Add(this.button200);
            this.player2SecretGridGroupBox.Location = new System.Drawing.Point(12, 4);
            this.player2SecretGridGroupBox.Name = "player2SecretGridGroupBox";
            this.player2SecretGridGroupBox.Size = new System.Drawing.Size(467, 451);
            this.player2SecretGridGroupBox.TabIndex = 100;
            this.player2SecretGridGroupBox.TabStop = false;
            this.player2SecretGridGroupBox.Text = "Player 2";
            this.player2SecretGridGroupBox.Visible = false;
            // 
            // button101
            // 
            this.button101.Location = new System.Drawing.Point(420, 406);
            this.button101.Name = "button101";
            this.button101.Size = new System.Drawing.Size(40, 37);
            this.button101.TabIndex = 99;
            this.button101.UseVisualStyleBackColor = true;
            // 
            // button102
            // 
            this.button102.Location = new System.Drawing.Point(374, 406);
            this.button102.Name = "button102";
            this.button102.Size = new System.Drawing.Size(40, 37);
            this.button102.TabIndex = 98;
            this.button102.UseVisualStyleBackColor = true;
            // 
            // button103
            // 
            this.button103.Location = new System.Drawing.Point(328, 406);
            this.button103.Name = "button103";
            this.button103.Size = new System.Drawing.Size(40, 37);
            this.button103.TabIndex = 97;
            this.button103.UseVisualStyleBackColor = true;
            // 
            // button104
            // 
            this.button104.Location = new System.Drawing.Point(282, 406);
            this.button104.Name = "button104";
            this.button104.Size = new System.Drawing.Size(40, 37);
            this.button104.TabIndex = 96;
            this.button104.UseVisualStyleBackColor = true;
            // 
            // button105
            // 
            this.button105.Location = new System.Drawing.Point(236, 406);
            this.button105.Name = "button105";
            this.button105.Size = new System.Drawing.Size(40, 37);
            this.button105.TabIndex = 95;
            this.button105.UseVisualStyleBackColor = true;
            // 
            // button106
            // 
            this.button106.Location = new System.Drawing.Point(190, 406);
            this.button106.Name = "button106";
            this.button106.Size = new System.Drawing.Size(40, 37);
            this.button106.TabIndex = 94;
            this.button106.UseVisualStyleBackColor = true;
            // 
            // button107
            // 
            this.button107.Location = new System.Drawing.Point(144, 406);
            this.button107.Name = "button107";
            this.button107.Size = new System.Drawing.Size(40, 37);
            this.button107.TabIndex = 93;
            this.button107.UseVisualStyleBackColor = true;
            // 
            // button108
            // 
            this.button108.Location = new System.Drawing.Point(98, 406);
            this.button108.Name = "button108";
            this.button108.Size = new System.Drawing.Size(40, 37);
            this.button108.TabIndex = 92;
            this.button108.UseVisualStyleBackColor = true;
            // 
            // button109
            // 
            this.button109.Location = new System.Drawing.Point(52, 406);
            this.button109.Name = "button109";
            this.button109.Size = new System.Drawing.Size(40, 37);
            this.button109.TabIndex = 91;
            this.button109.UseVisualStyleBackColor = true;
            // 
            // button110
            // 
            this.button110.Location = new System.Drawing.Point(6, 406);
            this.button110.Name = "button110";
            this.button110.Size = new System.Drawing.Size(40, 37);
            this.button110.TabIndex = 90;
            this.button110.UseVisualStyleBackColor = true;
            // 
            // button111
            // 
            this.button111.Location = new System.Drawing.Point(420, 363);
            this.button111.Name = "button111";
            this.button111.Size = new System.Drawing.Size(40, 37);
            this.button111.TabIndex = 89;
            this.button111.UseVisualStyleBackColor = true;
            // 
            // button112
            // 
            this.button112.Location = new System.Drawing.Point(374, 363);
            this.button112.Name = "button112";
            this.button112.Size = new System.Drawing.Size(40, 37);
            this.button112.TabIndex = 88;
            this.button112.UseVisualStyleBackColor = true;
            // 
            // button113
            // 
            this.button113.Location = new System.Drawing.Point(328, 363);
            this.button113.Name = "button113";
            this.button113.Size = new System.Drawing.Size(40, 37);
            this.button113.TabIndex = 87;
            this.button113.UseVisualStyleBackColor = true;
            // 
            // button114
            // 
            this.button114.Location = new System.Drawing.Point(282, 363);
            this.button114.Name = "button114";
            this.button114.Size = new System.Drawing.Size(40, 37);
            this.button114.TabIndex = 86;
            this.button114.UseVisualStyleBackColor = true;
            // 
            // button115
            // 
            this.button115.Location = new System.Drawing.Point(236, 363);
            this.button115.Name = "button115";
            this.button115.Size = new System.Drawing.Size(40, 37);
            this.button115.TabIndex = 85;
            this.button115.UseVisualStyleBackColor = true;
            // 
            // button116
            // 
            this.button116.Location = new System.Drawing.Point(190, 363);
            this.button116.Name = "button116";
            this.button116.Size = new System.Drawing.Size(40, 37);
            this.button116.TabIndex = 84;
            this.button116.UseVisualStyleBackColor = true;
            // 
            // button117
            // 
            this.button117.Location = new System.Drawing.Point(144, 363);
            this.button117.Name = "button117";
            this.button117.Size = new System.Drawing.Size(40, 37);
            this.button117.TabIndex = 83;
            this.button117.UseVisualStyleBackColor = true;
            // 
            // button118
            // 
            this.button118.Location = new System.Drawing.Point(98, 363);
            this.button118.Name = "button118";
            this.button118.Size = new System.Drawing.Size(40, 37);
            this.button118.TabIndex = 82;
            this.button118.UseVisualStyleBackColor = true;
            // 
            // button119
            // 
            this.button119.Location = new System.Drawing.Point(52, 363);
            this.button119.Name = "button119";
            this.button119.Size = new System.Drawing.Size(40, 37);
            this.button119.TabIndex = 81;
            this.button119.UseVisualStyleBackColor = true;
            // 
            // button120
            // 
            this.button120.Location = new System.Drawing.Point(6, 363);
            this.button120.Name = "button120";
            this.button120.Size = new System.Drawing.Size(40, 37);
            this.button120.TabIndex = 80;
            this.button120.UseVisualStyleBackColor = true;
            // 
            // button121
            // 
            this.button121.Location = new System.Drawing.Point(420, 320);
            this.button121.Name = "button121";
            this.button121.Size = new System.Drawing.Size(40, 37);
            this.button121.TabIndex = 79;
            this.button121.UseVisualStyleBackColor = true;
            // 
            // button122
            // 
            this.button122.Location = new System.Drawing.Point(374, 320);
            this.button122.Name = "button122";
            this.button122.Size = new System.Drawing.Size(40, 37);
            this.button122.TabIndex = 78;
            this.button122.UseVisualStyleBackColor = true;
            // 
            // button123
            // 
            this.button123.Location = new System.Drawing.Point(328, 320);
            this.button123.Name = "button123";
            this.button123.Size = new System.Drawing.Size(40, 37);
            this.button123.TabIndex = 77;
            this.button123.UseVisualStyleBackColor = true;
            // 
            // button124
            // 
            this.button124.Location = new System.Drawing.Point(282, 320);
            this.button124.Name = "button124";
            this.button124.Size = new System.Drawing.Size(40, 37);
            this.button124.TabIndex = 76;
            this.button124.UseVisualStyleBackColor = true;
            // 
            // button125
            // 
            this.button125.Location = new System.Drawing.Point(236, 320);
            this.button125.Name = "button125";
            this.button125.Size = new System.Drawing.Size(40, 37);
            this.button125.TabIndex = 75;
            this.button125.UseVisualStyleBackColor = true;
            // 
            // button126
            // 
            this.button126.Location = new System.Drawing.Point(190, 320);
            this.button126.Name = "button126";
            this.button126.Size = new System.Drawing.Size(40, 37);
            this.button126.TabIndex = 74;
            this.button126.UseVisualStyleBackColor = true;
            // 
            // button127
            // 
            this.button127.Location = new System.Drawing.Point(144, 320);
            this.button127.Name = "button127";
            this.button127.Size = new System.Drawing.Size(40, 37);
            this.button127.TabIndex = 73;
            this.button127.UseVisualStyleBackColor = true;
            // 
            // button128
            // 
            this.button128.Location = new System.Drawing.Point(98, 320);
            this.button128.Name = "button128";
            this.button128.Size = new System.Drawing.Size(40, 37);
            this.button128.TabIndex = 72;
            this.button128.UseVisualStyleBackColor = true;
            // 
            // button129
            // 
            this.button129.Location = new System.Drawing.Point(52, 320);
            this.button129.Name = "button129";
            this.button129.Size = new System.Drawing.Size(40, 37);
            this.button129.TabIndex = 71;
            this.button129.UseVisualStyleBackColor = true;
            // 
            // button130
            // 
            this.button130.Location = new System.Drawing.Point(6, 320);
            this.button130.Name = "button130";
            this.button130.Size = new System.Drawing.Size(40, 37);
            this.button130.TabIndex = 70;
            this.button130.UseVisualStyleBackColor = true;
            // 
            // button131
            // 
            this.button131.Location = new System.Drawing.Point(420, 277);
            this.button131.Name = "button131";
            this.button131.Size = new System.Drawing.Size(40, 37);
            this.button131.TabIndex = 69;
            this.button131.UseVisualStyleBackColor = true;
            // 
            // button132
            // 
            this.button132.Location = new System.Drawing.Point(374, 277);
            this.button132.Name = "button132";
            this.button132.Size = new System.Drawing.Size(40, 37);
            this.button132.TabIndex = 68;
            this.button132.UseVisualStyleBackColor = true;
            // 
            // button133
            // 
            this.button133.Location = new System.Drawing.Point(328, 277);
            this.button133.Name = "button133";
            this.button133.Size = new System.Drawing.Size(40, 37);
            this.button133.TabIndex = 67;
            this.button133.UseVisualStyleBackColor = true;
            // 
            // button134
            // 
            this.button134.Location = new System.Drawing.Point(282, 277);
            this.button134.Name = "button134";
            this.button134.Size = new System.Drawing.Size(40, 37);
            this.button134.TabIndex = 66;
            this.button134.UseVisualStyleBackColor = true;
            // 
            // button135
            // 
            this.button135.Location = new System.Drawing.Point(236, 277);
            this.button135.Name = "button135";
            this.button135.Size = new System.Drawing.Size(40, 37);
            this.button135.TabIndex = 65;
            this.button135.UseVisualStyleBackColor = true;
            // 
            // button136
            // 
            this.button136.Location = new System.Drawing.Point(190, 277);
            this.button136.Name = "button136";
            this.button136.Size = new System.Drawing.Size(40, 37);
            this.button136.TabIndex = 64;
            this.button136.UseVisualStyleBackColor = true;
            // 
            // button137
            // 
            this.button137.Location = new System.Drawing.Point(144, 277);
            this.button137.Name = "button137";
            this.button137.Size = new System.Drawing.Size(40, 37);
            this.button137.TabIndex = 63;
            this.button137.UseVisualStyleBackColor = true;
            // 
            // button138
            // 
            this.button138.Location = new System.Drawing.Point(98, 277);
            this.button138.Name = "button138";
            this.button138.Size = new System.Drawing.Size(40, 37);
            this.button138.TabIndex = 62;
            this.button138.UseVisualStyleBackColor = true;
            // 
            // button139
            // 
            this.button139.Location = new System.Drawing.Point(52, 277);
            this.button139.Name = "button139";
            this.button139.Size = new System.Drawing.Size(40, 37);
            this.button139.TabIndex = 61;
            this.button139.UseVisualStyleBackColor = true;
            // 
            // button140
            // 
            this.button140.Location = new System.Drawing.Point(6, 277);
            this.button140.Name = "button140";
            this.button140.Size = new System.Drawing.Size(40, 37);
            this.button140.TabIndex = 60;
            this.button140.UseVisualStyleBackColor = true;
            // 
            // button141
            // 
            this.button141.Location = new System.Drawing.Point(420, 234);
            this.button141.Name = "button141";
            this.button141.Size = new System.Drawing.Size(40, 37);
            this.button141.TabIndex = 59;
            this.button141.UseVisualStyleBackColor = true;
            // 
            // button142
            // 
            this.button142.Location = new System.Drawing.Point(374, 234);
            this.button142.Name = "button142";
            this.button142.Size = new System.Drawing.Size(40, 37);
            this.button142.TabIndex = 58;
            this.button142.UseVisualStyleBackColor = true;
            // 
            // button143
            // 
            this.button143.Location = new System.Drawing.Point(328, 234);
            this.button143.Name = "button143";
            this.button143.Size = new System.Drawing.Size(40, 37);
            this.button143.TabIndex = 57;
            this.button143.UseVisualStyleBackColor = true;
            // 
            // button144
            // 
            this.button144.Location = new System.Drawing.Point(282, 234);
            this.button144.Name = "button144";
            this.button144.Size = new System.Drawing.Size(40, 37);
            this.button144.TabIndex = 56;
            this.button144.UseVisualStyleBackColor = true;
            // 
            // button145
            // 
            this.button145.Location = new System.Drawing.Point(236, 234);
            this.button145.Name = "button145";
            this.button145.Size = new System.Drawing.Size(40, 37);
            this.button145.TabIndex = 55;
            this.button145.UseVisualStyleBackColor = true;
            // 
            // button146
            // 
            this.button146.Location = new System.Drawing.Point(190, 234);
            this.button146.Name = "button146";
            this.button146.Size = new System.Drawing.Size(40, 37);
            this.button146.TabIndex = 54;
            this.button146.UseVisualStyleBackColor = true;
            // 
            // button147
            // 
            this.button147.Location = new System.Drawing.Point(144, 234);
            this.button147.Name = "button147";
            this.button147.Size = new System.Drawing.Size(40, 37);
            this.button147.TabIndex = 53;
            this.button147.UseVisualStyleBackColor = true;
            // 
            // button148
            // 
            this.button148.Location = new System.Drawing.Point(98, 234);
            this.button148.Name = "button148";
            this.button148.Size = new System.Drawing.Size(40, 37);
            this.button148.TabIndex = 52;
            this.button148.UseVisualStyleBackColor = true;
            // 
            // button149
            // 
            this.button149.Location = new System.Drawing.Point(52, 234);
            this.button149.Name = "button149";
            this.button149.Size = new System.Drawing.Size(40, 37);
            this.button149.TabIndex = 51;
            this.button149.UseVisualStyleBackColor = true;
            // 
            // button150
            // 
            this.button150.Location = new System.Drawing.Point(6, 234);
            this.button150.Name = "button150";
            this.button150.Size = new System.Drawing.Size(40, 37);
            this.button150.TabIndex = 50;
            this.button150.UseVisualStyleBackColor = true;
            // 
            // button151
            // 
            this.button151.Location = new System.Drawing.Point(420, 192);
            this.button151.Name = "button151";
            this.button151.Size = new System.Drawing.Size(40, 37);
            this.button151.TabIndex = 49;
            this.button151.UseVisualStyleBackColor = true;
            // 
            // button152
            // 
            this.button152.Location = new System.Drawing.Point(374, 191);
            this.button152.Name = "button152";
            this.button152.Size = new System.Drawing.Size(40, 37);
            this.button152.TabIndex = 48;
            this.button152.UseVisualStyleBackColor = true;
            // 
            // button153
            // 
            this.button153.Location = new System.Drawing.Point(328, 191);
            this.button153.Name = "button153";
            this.button153.Size = new System.Drawing.Size(40, 37);
            this.button153.TabIndex = 47;
            this.button153.UseVisualStyleBackColor = true;
            // 
            // button154
            // 
            this.button154.Location = new System.Drawing.Point(282, 191);
            this.button154.Name = "button154";
            this.button154.Size = new System.Drawing.Size(40, 37);
            this.button154.TabIndex = 46;
            this.button154.UseVisualStyleBackColor = true;
            // 
            // button155
            // 
            this.button155.Location = new System.Drawing.Point(236, 191);
            this.button155.Name = "button155";
            this.button155.Size = new System.Drawing.Size(40, 37);
            this.button155.TabIndex = 45;
            this.button155.UseVisualStyleBackColor = true;
            // 
            // button156
            // 
            this.button156.Location = new System.Drawing.Point(190, 191);
            this.button156.Name = "button156";
            this.button156.Size = new System.Drawing.Size(40, 37);
            this.button156.TabIndex = 44;
            this.button156.UseVisualStyleBackColor = true;
            // 
            // button157
            // 
            this.button157.Location = new System.Drawing.Point(144, 191);
            this.button157.Name = "button157";
            this.button157.Size = new System.Drawing.Size(40, 37);
            this.button157.TabIndex = 43;
            this.button157.UseVisualStyleBackColor = true;
            // 
            // button158
            // 
            this.button158.Location = new System.Drawing.Point(98, 191);
            this.button158.Name = "button158";
            this.button158.Size = new System.Drawing.Size(40, 37);
            this.button158.TabIndex = 42;
            this.button158.UseVisualStyleBackColor = true;
            // 
            // button159
            // 
            this.button159.Location = new System.Drawing.Point(52, 191);
            this.button159.Name = "button159";
            this.button159.Size = new System.Drawing.Size(40, 37);
            this.button159.TabIndex = 41;
            this.button159.UseVisualStyleBackColor = true;
            // 
            // button160
            // 
            this.button160.Location = new System.Drawing.Point(6, 191);
            this.button160.Name = "button160";
            this.button160.Size = new System.Drawing.Size(40, 37);
            this.button160.TabIndex = 40;
            this.button160.UseVisualStyleBackColor = true;
            // 
            // button161
            // 
            this.button161.Location = new System.Drawing.Point(420, 149);
            this.button161.Name = "button161";
            this.button161.Size = new System.Drawing.Size(40, 37);
            this.button161.TabIndex = 39;
            this.button161.UseVisualStyleBackColor = true;
            // 
            // button162
            // 
            this.button162.Location = new System.Drawing.Point(374, 149);
            this.button162.Name = "button162";
            this.button162.Size = new System.Drawing.Size(40, 37);
            this.button162.TabIndex = 38;
            this.button162.UseVisualStyleBackColor = true;
            // 
            // button163
            // 
            this.button163.Location = new System.Drawing.Point(328, 149);
            this.button163.Name = "button163";
            this.button163.Size = new System.Drawing.Size(40, 37);
            this.button163.TabIndex = 37;
            this.button163.UseVisualStyleBackColor = true;
            // 
            // button164
            // 
            this.button164.Location = new System.Drawing.Point(282, 148);
            this.button164.Name = "button164";
            this.button164.Size = new System.Drawing.Size(40, 37);
            this.button164.TabIndex = 36;
            this.button164.UseVisualStyleBackColor = true;
            // 
            // button165
            // 
            this.button165.Location = new System.Drawing.Point(236, 149);
            this.button165.Name = "button165";
            this.button165.Size = new System.Drawing.Size(40, 37);
            this.button165.TabIndex = 35;
            this.button165.UseVisualStyleBackColor = true;
            // 
            // button166
            // 
            this.button166.Location = new System.Drawing.Point(190, 149);
            this.button166.Name = "button166";
            this.button166.Size = new System.Drawing.Size(40, 37);
            this.button166.TabIndex = 34;
            this.button166.UseVisualStyleBackColor = true;
            // 
            // button167
            // 
            this.button167.Location = new System.Drawing.Point(144, 148);
            this.button167.Name = "button167";
            this.button167.Size = new System.Drawing.Size(40, 37);
            this.button167.TabIndex = 33;
            this.button167.UseVisualStyleBackColor = true;
            // 
            // button168
            // 
            this.button168.Location = new System.Drawing.Point(98, 149);
            this.button168.Name = "button168";
            this.button168.Size = new System.Drawing.Size(40, 37);
            this.button168.TabIndex = 32;
            this.button168.UseVisualStyleBackColor = true;
            // 
            // button169
            // 
            this.button169.Location = new System.Drawing.Point(52, 149);
            this.button169.Name = "button169";
            this.button169.Size = new System.Drawing.Size(40, 37);
            this.button169.TabIndex = 31;
            this.button169.UseVisualStyleBackColor = true;
            // 
            // button170
            // 
            this.button170.Location = new System.Drawing.Point(6, 148);
            this.button170.Name = "button170";
            this.button170.Size = new System.Drawing.Size(40, 37);
            this.button170.TabIndex = 30;
            this.button170.UseVisualStyleBackColor = true;
            // 
            // button171
            // 
            this.button171.Location = new System.Drawing.Point(421, 105);
            this.button171.Name = "button171";
            this.button171.Size = new System.Drawing.Size(40, 37);
            this.button171.TabIndex = 29;
            this.button171.UseVisualStyleBackColor = true;
            // 
            // button172
            // 
            this.button172.Location = new System.Drawing.Point(374, 105);
            this.button172.Name = "button172";
            this.button172.Size = new System.Drawing.Size(40, 37);
            this.button172.TabIndex = 28;
            this.button172.UseVisualStyleBackColor = true;
            // 
            // button173
            // 
            this.button173.Location = new System.Drawing.Point(328, 105);
            this.button173.Name = "button173";
            this.button173.Size = new System.Drawing.Size(40, 37);
            this.button173.TabIndex = 27;
            this.button173.UseVisualStyleBackColor = true;
            // 
            // button174
            // 
            this.button174.Location = new System.Drawing.Point(282, 105);
            this.button174.Name = "button174";
            this.button174.Size = new System.Drawing.Size(40, 37);
            this.button174.TabIndex = 26;
            this.button174.UseVisualStyleBackColor = true;
            // 
            // button175
            // 
            this.button175.Location = new System.Drawing.Point(236, 105);
            this.button175.Name = "button175";
            this.button175.Size = new System.Drawing.Size(40, 37);
            this.button175.TabIndex = 25;
            this.button175.UseVisualStyleBackColor = true;
            // 
            // button176
            // 
            this.button176.Location = new System.Drawing.Point(190, 105);
            this.button176.Name = "button176";
            this.button176.Size = new System.Drawing.Size(40, 37);
            this.button176.TabIndex = 24;
            this.button176.UseVisualStyleBackColor = true;
            // 
            // button177
            // 
            this.button177.Location = new System.Drawing.Point(144, 105);
            this.button177.Name = "button177";
            this.button177.Size = new System.Drawing.Size(40, 37);
            this.button177.TabIndex = 23;
            this.button177.UseVisualStyleBackColor = true;
            // 
            // button178
            // 
            this.button178.Location = new System.Drawing.Point(98, 105);
            this.button178.Name = "button178";
            this.button178.Size = new System.Drawing.Size(40, 37);
            this.button178.TabIndex = 22;
            this.button178.UseVisualStyleBackColor = true;
            // 
            // button179
            // 
            this.button179.Location = new System.Drawing.Point(52, 105);
            this.button179.Name = "button179";
            this.button179.Size = new System.Drawing.Size(40, 37);
            this.button179.TabIndex = 21;
            this.button179.UseVisualStyleBackColor = true;
            // 
            // button180
            // 
            this.button180.Location = new System.Drawing.Point(6, 105);
            this.button180.Name = "button180";
            this.button180.Size = new System.Drawing.Size(40, 37);
            this.button180.TabIndex = 20;
            this.button180.UseVisualStyleBackColor = true;
            // 
            // button181
            // 
            this.button181.Location = new System.Drawing.Point(420, 62);
            this.button181.Name = "button181";
            this.button181.Size = new System.Drawing.Size(40, 37);
            this.button181.TabIndex = 19;
            this.button181.UseVisualStyleBackColor = true;
            // 
            // button182
            // 
            this.button182.Location = new System.Drawing.Point(374, 62);
            this.button182.Name = "button182";
            this.button182.Size = new System.Drawing.Size(40, 37);
            this.button182.TabIndex = 18;
            this.button182.UseVisualStyleBackColor = true;
            // 
            // button183
            // 
            this.button183.Location = new System.Drawing.Point(328, 62);
            this.button183.Name = "button183";
            this.button183.Size = new System.Drawing.Size(40, 37);
            this.button183.TabIndex = 17;
            this.button183.UseVisualStyleBackColor = true;
            // 
            // button184
            // 
            this.button184.Location = new System.Drawing.Point(282, 62);
            this.button184.Name = "button184";
            this.button184.Size = new System.Drawing.Size(40, 37);
            this.button184.TabIndex = 16;
            this.button184.UseVisualStyleBackColor = true;
            // 
            // button185
            // 
            this.button185.Location = new System.Drawing.Point(236, 62);
            this.button185.Name = "button185";
            this.button185.Size = new System.Drawing.Size(40, 37);
            this.button185.TabIndex = 15;
            this.button185.UseVisualStyleBackColor = true;
            // 
            // button186
            // 
            this.button186.Location = new System.Drawing.Point(190, 62);
            this.button186.Name = "button186";
            this.button186.Size = new System.Drawing.Size(40, 37);
            this.button186.TabIndex = 14;
            this.button186.UseVisualStyleBackColor = true;
            // 
            // button187
            // 
            this.button187.Location = new System.Drawing.Point(144, 62);
            this.button187.Name = "button187";
            this.button187.Size = new System.Drawing.Size(40, 37);
            this.button187.TabIndex = 13;
            this.button187.UseVisualStyleBackColor = true;
            // 
            // button188
            // 
            this.button188.Location = new System.Drawing.Point(98, 62);
            this.button188.Name = "button188";
            this.button188.Size = new System.Drawing.Size(40, 37);
            this.button188.TabIndex = 12;
            this.button188.UseVisualStyleBackColor = true;
            // 
            // button189
            // 
            this.button189.Location = new System.Drawing.Point(52, 62);
            this.button189.Name = "button189";
            this.button189.Size = new System.Drawing.Size(40, 37);
            this.button189.TabIndex = 11;
            this.button189.UseVisualStyleBackColor = true;
            // 
            // button190
            // 
            this.button190.Location = new System.Drawing.Point(6, 62);
            this.button190.Name = "button190";
            this.button190.Size = new System.Drawing.Size(40, 37);
            this.button190.TabIndex = 10;
            this.button190.UseVisualStyleBackColor = true;
            // 
            // button191
            // 
            this.button191.Location = new System.Drawing.Point(420, 19);
            this.button191.Name = "button191";
            this.button191.Size = new System.Drawing.Size(40, 37);
            this.button191.TabIndex = 9;
            this.button191.UseVisualStyleBackColor = true;
            // 
            // button192
            // 
            this.button192.Location = new System.Drawing.Point(374, 19);
            this.button192.Name = "button192";
            this.button192.Size = new System.Drawing.Size(40, 37);
            this.button192.TabIndex = 8;
            this.button192.UseVisualStyleBackColor = true;
            // 
            // button193
            // 
            this.button193.Location = new System.Drawing.Point(328, 19);
            this.button193.Name = "button193";
            this.button193.Size = new System.Drawing.Size(40, 37);
            this.button193.TabIndex = 7;
            this.button193.UseVisualStyleBackColor = true;
            // 
            // button194
            // 
            this.button194.Location = new System.Drawing.Point(282, 19);
            this.button194.Name = "button194";
            this.button194.Size = new System.Drawing.Size(40, 37);
            this.button194.TabIndex = 6;
            this.button194.UseVisualStyleBackColor = true;
            // 
            // button195
            // 
            this.button195.Location = new System.Drawing.Point(236, 19);
            this.button195.Name = "button195";
            this.button195.Size = new System.Drawing.Size(40, 37);
            this.button195.TabIndex = 5;
            this.button195.UseVisualStyleBackColor = true;
            // 
            // button196
            // 
            this.button196.Location = new System.Drawing.Point(190, 19);
            this.button196.Name = "button196";
            this.button196.Size = new System.Drawing.Size(40, 37);
            this.button196.TabIndex = 4;
            this.button196.UseVisualStyleBackColor = true;
            // 
            // button197
            // 
            this.button197.Location = new System.Drawing.Point(144, 19);
            this.button197.Name = "button197";
            this.button197.Size = new System.Drawing.Size(40, 37);
            this.button197.TabIndex = 3;
            this.button197.UseVisualStyleBackColor = true;
            // 
            // button198
            // 
            this.button198.Location = new System.Drawing.Point(98, 19);
            this.button198.Name = "button198";
            this.button198.Size = new System.Drawing.Size(40, 37);
            this.button198.TabIndex = 2;
            this.button198.UseVisualStyleBackColor = true;
            // 
            // button199
            // 
            this.button199.Location = new System.Drawing.Point(52, 19);
            this.button199.Name = "button199";
            this.button199.Size = new System.Drawing.Size(40, 37);
            this.button199.TabIndex = 1;
            this.button199.UseVisualStyleBackColor = true;
            // 
            // button200
            // 
            this.button200.Location = new System.Drawing.Point(6, 19);
            this.button200.Name = "button200";
            this.button200.Size = new System.Drawing.Size(40, 37);
            this.button200.TabIndex = 0;
            this.button200.UseVisualStyleBackColor = true;
            // 
            // player1PublicGridGroupBox
            // 
            this.player1PublicGridGroupBox.Controls.Add(this.player2PublicGridGroupBox);
            this.player1PublicGridGroupBox.Controls.Add(this.button201);
            this.player1PublicGridGroupBox.Controls.Add(this.button202);
            this.player1PublicGridGroupBox.Controls.Add(this.button203);
            this.player1PublicGridGroupBox.Controls.Add(this.button204);
            this.player1PublicGridGroupBox.Controls.Add(this.button205);
            this.player1PublicGridGroupBox.Controls.Add(this.button206);
            this.player1PublicGridGroupBox.Controls.Add(this.button207);
            this.player1PublicGridGroupBox.Controls.Add(this.button208);
            this.player1PublicGridGroupBox.Controls.Add(this.button209);
            this.player1PublicGridGroupBox.Controls.Add(this.button210);
            this.player1PublicGridGroupBox.Controls.Add(this.button211);
            this.player1PublicGridGroupBox.Controls.Add(this.button212);
            this.player1PublicGridGroupBox.Controls.Add(this.button213);
            this.player1PublicGridGroupBox.Controls.Add(this.button214);
            this.player1PublicGridGroupBox.Controls.Add(this.button215);
            this.player1PublicGridGroupBox.Controls.Add(this.button216);
            this.player1PublicGridGroupBox.Controls.Add(this.button217);
            this.player1PublicGridGroupBox.Controls.Add(this.button218);
            this.player1PublicGridGroupBox.Controls.Add(this.button219);
            this.player1PublicGridGroupBox.Controls.Add(this.button220);
            this.player1PublicGridGroupBox.Controls.Add(this.button221);
            this.player1PublicGridGroupBox.Controls.Add(this.button222);
            this.player1PublicGridGroupBox.Controls.Add(this.button223);
            this.player1PublicGridGroupBox.Controls.Add(this.button224);
            this.player1PublicGridGroupBox.Controls.Add(this.button225);
            this.player1PublicGridGroupBox.Controls.Add(this.button226);
            this.player1PublicGridGroupBox.Controls.Add(this.button227);
            this.player1PublicGridGroupBox.Controls.Add(this.button228);
            this.player1PublicGridGroupBox.Controls.Add(this.button229);
            this.player1PublicGridGroupBox.Controls.Add(this.button230);
            this.player1PublicGridGroupBox.Controls.Add(this.button231);
            this.player1PublicGridGroupBox.Controls.Add(this.button232);
            this.player1PublicGridGroupBox.Controls.Add(this.button233);
            this.player1PublicGridGroupBox.Controls.Add(this.button234);
            this.player1PublicGridGroupBox.Controls.Add(this.button235);
            this.player1PublicGridGroupBox.Controls.Add(this.button236);
            this.player1PublicGridGroupBox.Controls.Add(this.button237);
            this.player1PublicGridGroupBox.Controls.Add(this.button238);
            this.player1PublicGridGroupBox.Controls.Add(this.button239);
            this.player1PublicGridGroupBox.Controls.Add(this.button240);
            this.player1PublicGridGroupBox.Controls.Add(this.button241);
            this.player1PublicGridGroupBox.Controls.Add(this.button242);
            this.player1PublicGridGroupBox.Controls.Add(this.button243);
            this.player1PublicGridGroupBox.Controls.Add(this.button244);
            this.player1PublicGridGroupBox.Controls.Add(this.button245);
            this.player1PublicGridGroupBox.Controls.Add(this.button246);
            this.player1PublicGridGroupBox.Controls.Add(this.button247);
            this.player1PublicGridGroupBox.Controls.Add(this.button248);
            this.player1PublicGridGroupBox.Controls.Add(this.button249);
            this.player1PublicGridGroupBox.Controls.Add(this.button250);
            this.player1PublicGridGroupBox.Controls.Add(this.button251);
            this.player1PublicGridGroupBox.Controls.Add(this.button252);
            this.player1PublicGridGroupBox.Controls.Add(this.button253);
            this.player1PublicGridGroupBox.Controls.Add(this.button254);
            this.player1PublicGridGroupBox.Controls.Add(this.button255);
            this.player1PublicGridGroupBox.Controls.Add(this.button256);
            this.player1PublicGridGroupBox.Controls.Add(this.button257);
            this.player1PublicGridGroupBox.Controls.Add(this.button258);
            this.player1PublicGridGroupBox.Controls.Add(this.button259);
            this.player1PublicGridGroupBox.Controls.Add(this.button260);
            this.player1PublicGridGroupBox.Controls.Add(this.button261);
            this.player1PublicGridGroupBox.Controls.Add(this.button262);
            this.player1PublicGridGroupBox.Controls.Add(this.button263);
            this.player1PublicGridGroupBox.Controls.Add(this.button264);
            this.player1PublicGridGroupBox.Controls.Add(this.button265);
            this.player1PublicGridGroupBox.Controls.Add(this.button266);
            this.player1PublicGridGroupBox.Controls.Add(this.button267);
            this.player1PublicGridGroupBox.Controls.Add(this.button268);
            this.player1PublicGridGroupBox.Controls.Add(this.button269);
            this.player1PublicGridGroupBox.Controls.Add(this.button270);
            this.player1PublicGridGroupBox.Controls.Add(this.button271);
            this.player1PublicGridGroupBox.Controls.Add(this.button272);
            this.player1PublicGridGroupBox.Controls.Add(this.button273);
            this.player1PublicGridGroupBox.Controls.Add(this.button274);
            this.player1PublicGridGroupBox.Controls.Add(this.button275);
            this.player1PublicGridGroupBox.Controls.Add(this.button276);
            this.player1PublicGridGroupBox.Controls.Add(this.button277);
            this.player1PublicGridGroupBox.Controls.Add(this.button278);
            this.player1PublicGridGroupBox.Controls.Add(this.button279);
            this.player1PublicGridGroupBox.Controls.Add(this.button280);
            this.player1PublicGridGroupBox.Controls.Add(this.button281);
            this.player1PublicGridGroupBox.Controls.Add(this.button282);
            this.player1PublicGridGroupBox.Controls.Add(this.button283);
            this.player1PublicGridGroupBox.Controls.Add(this.button284);
            this.player1PublicGridGroupBox.Controls.Add(this.button285);
            this.player1PublicGridGroupBox.Controls.Add(this.button286);
            this.player1PublicGridGroupBox.Controls.Add(this.button287);
            this.player1PublicGridGroupBox.Controls.Add(this.button288);
            this.player1PublicGridGroupBox.Controls.Add(this.button289);
            this.player1PublicGridGroupBox.Controls.Add(this.button290);
            this.player1PublicGridGroupBox.Controls.Add(this.button291);
            this.player1PublicGridGroupBox.Controls.Add(this.button292);
            this.player1PublicGridGroupBox.Controls.Add(this.button293);
            this.player1PublicGridGroupBox.Controls.Add(this.button294);
            this.player1PublicGridGroupBox.Controls.Add(this.button295);
            this.player1PublicGridGroupBox.Controls.Add(this.button296);
            this.player1PublicGridGroupBox.Controls.Add(this.button297);
            this.player1PublicGridGroupBox.Controls.Add(this.button298);
            this.player1PublicGridGroupBox.Controls.Add(this.button299);
            this.player1PublicGridGroupBox.Controls.Add(this.button300);
            this.player1PublicGridGroupBox.Location = new System.Drawing.Point(0, 0);
            this.player1PublicGridGroupBox.Name = "player1PublicGridGroupBox";
            this.player1PublicGridGroupBox.Size = new System.Drawing.Size(467, 451);
            this.player1PublicGridGroupBox.TabIndex = 101;
            this.player1PublicGridGroupBox.TabStop = false;
            this.player1PublicGridGroupBox.Text = "Player 1\'s Turn";
            this.player1PublicGridGroupBox.Visible = false;
            // 
            // button201
            // 
            this.button201.Location = new System.Drawing.Point(420, 406);
            this.button201.Name = "button201";
            this.button201.Size = new System.Drawing.Size(40, 37);
            this.button201.TabIndex = 99;
            this.button201.UseVisualStyleBackColor = true;
            // 
            // button202
            // 
            this.button202.Location = new System.Drawing.Point(374, 406);
            this.button202.Name = "button202";
            this.button202.Size = new System.Drawing.Size(40, 37);
            this.button202.TabIndex = 98;
            this.button202.UseVisualStyleBackColor = true;
            // 
            // button203
            // 
            this.button203.Location = new System.Drawing.Point(328, 406);
            this.button203.Name = "button203";
            this.button203.Size = new System.Drawing.Size(40, 37);
            this.button203.TabIndex = 97;
            this.button203.UseVisualStyleBackColor = true;
            // 
            // button204
            // 
            this.button204.Location = new System.Drawing.Point(282, 406);
            this.button204.Name = "button204";
            this.button204.Size = new System.Drawing.Size(40, 37);
            this.button204.TabIndex = 96;
            this.button204.UseVisualStyleBackColor = true;
            // 
            // button205
            // 
            this.button205.Location = new System.Drawing.Point(236, 406);
            this.button205.Name = "button205";
            this.button205.Size = new System.Drawing.Size(40, 37);
            this.button205.TabIndex = 95;
            this.button205.UseVisualStyleBackColor = true;
            // 
            // button206
            // 
            this.button206.Location = new System.Drawing.Point(190, 406);
            this.button206.Name = "button206";
            this.button206.Size = new System.Drawing.Size(40, 37);
            this.button206.TabIndex = 94;
            this.button206.UseVisualStyleBackColor = true;
            // 
            // button207
            // 
            this.button207.Location = new System.Drawing.Point(144, 406);
            this.button207.Name = "button207";
            this.button207.Size = new System.Drawing.Size(40, 37);
            this.button207.TabIndex = 93;
            this.button207.UseVisualStyleBackColor = true;
            // 
            // button208
            // 
            this.button208.Location = new System.Drawing.Point(98, 406);
            this.button208.Name = "button208";
            this.button208.Size = new System.Drawing.Size(40, 37);
            this.button208.TabIndex = 92;
            this.button208.UseVisualStyleBackColor = true;
            // 
            // button209
            // 
            this.button209.Location = new System.Drawing.Point(52, 406);
            this.button209.Name = "button209";
            this.button209.Size = new System.Drawing.Size(40, 37);
            this.button209.TabIndex = 91;
            this.button209.UseVisualStyleBackColor = true;
            // 
            // button210
            // 
            this.button210.Location = new System.Drawing.Point(6, 406);
            this.button210.Name = "button210";
            this.button210.Size = new System.Drawing.Size(40, 37);
            this.button210.TabIndex = 90;
            this.button210.UseVisualStyleBackColor = true;
            // 
            // button211
            // 
            this.button211.Location = new System.Drawing.Point(420, 363);
            this.button211.Name = "button211";
            this.button211.Size = new System.Drawing.Size(40, 37);
            this.button211.TabIndex = 89;
            this.button211.UseVisualStyleBackColor = true;
            // 
            // button212
            // 
            this.button212.Location = new System.Drawing.Point(374, 363);
            this.button212.Name = "button212";
            this.button212.Size = new System.Drawing.Size(40, 37);
            this.button212.TabIndex = 88;
            this.button212.UseVisualStyleBackColor = true;
            // 
            // button213
            // 
            this.button213.Location = new System.Drawing.Point(328, 363);
            this.button213.Name = "button213";
            this.button213.Size = new System.Drawing.Size(40, 37);
            this.button213.TabIndex = 87;
            this.button213.UseVisualStyleBackColor = true;
            // 
            // button214
            // 
            this.button214.Location = new System.Drawing.Point(282, 363);
            this.button214.Name = "button214";
            this.button214.Size = new System.Drawing.Size(40, 37);
            this.button214.TabIndex = 86;
            this.button214.UseVisualStyleBackColor = true;
            // 
            // button215
            // 
            this.button215.Location = new System.Drawing.Point(236, 363);
            this.button215.Name = "button215";
            this.button215.Size = new System.Drawing.Size(40, 37);
            this.button215.TabIndex = 85;
            this.button215.UseVisualStyleBackColor = true;
            // 
            // button216
            // 
            this.button216.Location = new System.Drawing.Point(190, 363);
            this.button216.Name = "button216";
            this.button216.Size = new System.Drawing.Size(40, 37);
            this.button216.TabIndex = 84;
            this.button216.UseVisualStyleBackColor = true;
            // 
            // button217
            // 
            this.button217.Location = new System.Drawing.Point(144, 363);
            this.button217.Name = "button217";
            this.button217.Size = new System.Drawing.Size(40, 37);
            this.button217.TabIndex = 83;
            this.button217.UseVisualStyleBackColor = true;
            // 
            // button218
            // 
            this.button218.Location = new System.Drawing.Point(98, 363);
            this.button218.Name = "button218";
            this.button218.Size = new System.Drawing.Size(40, 37);
            this.button218.TabIndex = 82;
            this.button218.UseVisualStyleBackColor = true;
            // 
            // button219
            // 
            this.button219.Location = new System.Drawing.Point(52, 363);
            this.button219.Name = "button219";
            this.button219.Size = new System.Drawing.Size(40, 37);
            this.button219.TabIndex = 81;
            this.button219.UseVisualStyleBackColor = true;
            // 
            // button220
            // 
            this.button220.Location = new System.Drawing.Point(6, 363);
            this.button220.Name = "button220";
            this.button220.Size = new System.Drawing.Size(40, 37);
            this.button220.TabIndex = 80;
            this.button220.UseVisualStyleBackColor = true;
            // 
            // button221
            // 
            this.button221.Location = new System.Drawing.Point(420, 320);
            this.button221.Name = "button221";
            this.button221.Size = new System.Drawing.Size(40, 37);
            this.button221.TabIndex = 79;
            this.button221.UseVisualStyleBackColor = true;
            // 
            // button222
            // 
            this.button222.Location = new System.Drawing.Point(374, 320);
            this.button222.Name = "button222";
            this.button222.Size = new System.Drawing.Size(40, 37);
            this.button222.TabIndex = 78;
            this.button222.UseVisualStyleBackColor = true;
            // 
            // button223
            // 
            this.button223.Location = new System.Drawing.Point(328, 320);
            this.button223.Name = "button223";
            this.button223.Size = new System.Drawing.Size(40, 37);
            this.button223.TabIndex = 77;
            this.button223.UseVisualStyleBackColor = true;
            // 
            // button224
            // 
            this.button224.Location = new System.Drawing.Point(282, 320);
            this.button224.Name = "button224";
            this.button224.Size = new System.Drawing.Size(40, 37);
            this.button224.TabIndex = 76;
            this.button224.UseVisualStyleBackColor = true;
            // 
            // button225
            // 
            this.button225.Location = new System.Drawing.Point(236, 320);
            this.button225.Name = "button225";
            this.button225.Size = new System.Drawing.Size(40, 37);
            this.button225.TabIndex = 75;
            this.button225.UseVisualStyleBackColor = true;
            // 
            // button226
            // 
            this.button226.Location = new System.Drawing.Point(190, 320);
            this.button226.Name = "button226";
            this.button226.Size = new System.Drawing.Size(40, 37);
            this.button226.TabIndex = 74;
            this.button226.UseVisualStyleBackColor = true;
            // 
            // button227
            // 
            this.button227.Location = new System.Drawing.Point(144, 320);
            this.button227.Name = "button227";
            this.button227.Size = new System.Drawing.Size(40, 37);
            this.button227.TabIndex = 73;
            this.button227.UseVisualStyleBackColor = true;
            // 
            // button228
            // 
            this.button228.Location = new System.Drawing.Point(98, 320);
            this.button228.Name = "button228";
            this.button228.Size = new System.Drawing.Size(40, 37);
            this.button228.TabIndex = 72;
            this.button228.UseVisualStyleBackColor = true;
            // 
            // button229
            // 
            this.button229.Location = new System.Drawing.Point(52, 320);
            this.button229.Name = "button229";
            this.button229.Size = new System.Drawing.Size(40, 37);
            this.button229.TabIndex = 71;
            this.button229.UseVisualStyleBackColor = true;
            // 
            // button230
            // 
            this.button230.Location = new System.Drawing.Point(6, 320);
            this.button230.Name = "button230";
            this.button230.Size = new System.Drawing.Size(40, 37);
            this.button230.TabIndex = 70;
            this.button230.UseVisualStyleBackColor = true;
            // 
            // button231
            // 
            this.button231.Location = new System.Drawing.Point(420, 277);
            this.button231.Name = "button231";
            this.button231.Size = new System.Drawing.Size(40, 37);
            this.button231.TabIndex = 69;
            this.button231.UseVisualStyleBackColor = true;
            // 
            // button232
            // 
            this.button232.Location = new System.Drawing.Point(374, 277);
            this.button232.Name = "button232";
            this.button232.Size = new System.Drawing.Size(40, 37);
            this.button232.TabIndex = 68;
            this.button232.UseVisualStyleBackColor = true;
            // 
            // button233
            // 
            this.button233.Location = new System.Drawing.Point(328, 277);
            this.button233.Name = "button233";
            this.button233.Size = new System.Drawing.Size(40, 37);
            this.button233.TabIndex = 67;
            this.button233.UseVisualStyleBackColor = true;
            // 
            // button234
            // 
            this.button234.Location = new System.Drawing.Point(282, 277);
            this.button234.Name = "button234";
            this.button234.Size = new System.Drawing.Size(40, 37);
            this.button234.TabIndex = 66;
            this.button234.UseVisualStyleBackColor = true;
            // 
            // button235
            // 
            this.button235.Location = new System.Drawing.Point(236, 277);
            this.button235.Name = "button235";
            this.button235.Size = new System.Drawing.Size(40, 37);
            this.button235.TabIndex = 65;
            this.button235.UseVisualStyleBackColor = true;
            // 
            // button236
            // 
            this.button236.Location = new System.Drawing.Point(190, 277);
            this.button236.Name = "button236";
            this.button236.Size = new System.Drawing.Size(40, 37);
            this.button236.TabIndex = 64;
            this.button236.UseVisualStyleBackColor = true;
            // 
            // button237
            // 
            this.button237.Location = new System.Drawing.Point(144, 277);
            this.button237.Name = "button237";
            this.button237.Size = new System.Drawing.Size(40, 37);
            this.button237.TabIndex = 63;
            this.button237.UseVisualStyleBackColor = true;
            // 
            // button238
            // 
            this.button238.Location = new System.Drawing.Point(98, 277);
            this.button238.Name = "button238";
            this.button238.Size = new System.Drawing.Size(40, 37);
            this.button238.TabIndex = 62;
            this.button238.UseVisualStyleBackColor = true;
            // 
            // button239
            // 
            this.button239.Location = new System.Drawing.Point(52, 277);
            this.button239.Name = "button239";
            this.button239.Size = new System.Drawing.Size(40, 37);
            this.button239.TabIndex = 61;
            this.button239.UseVisualStyleBackColor = true;
            // 
            // button240
            // 
            this.button240.Location = new System.Drawing.Point(6, 277);
            this.button240.Name = "button240";
            this.button240.Size = new System.Drawing.Size(40, 37);
            this.button240.TabIndex = 60;
            this.button240.UseVisualStyleBackColor = true;
            // 
            // button241
            // 
            this.button241.Location = new System.Drawing.Point(420, 234);
            this.button241.Name = "button241";
            this.button241.Size = new System.Drawing.Size(40, 37);
            this.button241.TabIndex = 59;
            this.button241.UseVisualStyleBackColor = true;
            // 
            // button242
            // 
            this.button242.Location = new System.Drawing.Point(374, 234);
            this.button242.Name = "button242";
            this.button242.Size = new System.Drawing.Size(40, 37);
            this.button242.TabIndex = 58;
            this.button242.UseVisualStyleBackColor = true;
            // 
            // button243
            // 
            this.button243.Location = new System.Drawing.Point(328, 234);
            this.button243.Name = "button243";
            this.button243.Size = new System.Drawing.Size(40, 37);
            this.button243.TabIndex = 57;
            this.button243.UseVisualStyleBackColor = true;
            // 
            // button244
            // 
            this.button244.Location = new System.Drawing.Point(282, 234);
            this.button244.Name = "button244";
            this.button244.Size = new System.Drawing.Size(40, 37);
            this.button244.TabIndex = 56;
            this.button244.UseVisualStyleBackColor = true;
            // 
            // button245
            // 
            this.button245.Location = new System.Drawing.Point(236, 234);
            this.button245.Name = "button245";
            this.button245.Size = new System.Drawing.Size(40, 37);
            this.button245.TabIndex = 55;
            this.button245.UseVisualStyleBackColor = true;
            // 
            // button246
            // 
            this.button246.Location = new System.Drawing.Point(190, 234);
            this.button246.Name = "button246";
            this.button246.Size = new System.Drawing.Size(40, 37);
            this.button246.TabIndex = 54;
            this.button246.UseVisualStyleBackColor = true;
            // 
            // button247
            // 
            this.button247.Location = new System.Drawing.Point(144, 234);
            this.button247.Name = "button247";
            this.button247.Size = new System.Drawing.Size(40, 37);
            this.button247.TabIndex = 53;
            this.button247.UseVisualStyleBackColor = true;
            // 
            // button248
            // 
            this.button248.Location = new System.Drawing.Point(98, 234);
            this.button248.Name = "button248";
            this.button248.Size = new System.Drawing.Size(40, 37);
            this.button248.TabIndex = 52;
            this.button248.UseVisualStyleBackColor = true;
            // 
            // button249
            // 
            this.button249.Location = new System.Drawing.Point(52, 234);
            this.button249.Name = "button249";
            this.button249.Size = new System.Drawing.Size(40, 37);
            this.button249.TabIndex = 51;
            this.button249.UseVisualStyleBackColor = true;
            // 
            // button250
            // 
            this.button250.Location = new System.Drawing.Point(6, 234);
            this.button250.Name = "button250";
            this.button250.Size = new System.Drawing.Size(40, 37);
            this.button250.TabIndex = 50;
            this.button250.UseVisualStyleBackColor = true;
            // 
            // button251
            // 
            this.button251.Location = new System.Drawing.Point(420, 192);
            this.button251.Name = "button251";
            this.button251.Size = new System.Drawing.Size(40, 37);
            this.button251.TabIndex = 49;
            this.button251.UseVisualStyleBackColor = true;
            // 
            // button252
            // 
            this.button252.Location = new System.Drawing.Point(374, 191);
            this.button252.Name = "button252";
            this.button252.Size = new System.Drawing.Size(40, 37);
            this.button252.TabIndex = 48;
            this.button252.UseVisualStyleBackColor = true;
            // 
            // button253
            // 
            this.button253.Location = new System.Drawing.Point(328, 191);
            this.button253.Name = "button253";
            this.button253.Size = new System.Drawing.Size(40, 37);
            this.button253.TabIndex = 47;
            this.button253.UseVisualStyleBackColor = true;
            // 
            // button254
            // 
            this.button254.Location = new System.Drawing.Point(282, 191);
            this.button254.Name = "button254";
            this.button254.Size = new System.Drawing.Size(40, 37);
            this.button254.TabIndex = 46;
            this.button254.UseVisualStyleBackColor = true;
            // 
            // button255
            // 
            this.button255.Location = new System.Drawing.Point(236, 191);
            this.button255.Name = "button255";
            this.button255.Size = new System.Drawing.Size(40, 37);
            this.button255.TabIndex = 45;
            this.button255.UseVisualStyleBackColor = true;
            // 
            // button256
            // 
            this.button256.Location = new System.Drawing.Point(190, 191);
            this.button256.Name = "button256";
            this.button256.Size = new System.Drawing.Size(40, 37);
            this.button256.TabIndex = 44;
            this.button256.UseVisualStyleBackColor = true;
            // 
            // button257
            // 
            this.button257.Location = new System.Drawing.Point(144, 191);
            this.button257.Name = "button257";
            this.button257.Size = new System.Drawing.Size(40, 37);
            this.button257.TabIndex = 43;
            this.button257.UseVisualStyleBackColor = true;
            // 
            // button258
            // 
            this.button258.Location = new System.Drawing.Point(98, 191);
            this.button258.Name = "button258";
            this.button258.Size = new System.Drawing.Size(40, 37);
            this.button258.TabIndex = 42;
            this.button258.UseVisualStyleBackColor = true;
            // 
            // button259
            // 
            this.button259.Location = new System.Drawing.Point(52, 191);
            this.button259.Name = "button259";
            this.button259.Size = new System.Drawing.Size(40, 37);
            this.button259.TabIndex = 41;
            this.button259.UseVisualStyleBackColor = true;
            // 
            // button260
            // 
            this.button260.Location = new System.Drawing.Point(6, 191);
            this.button260.Name = "button260";
            this.button260.Size = new System.Drawing.Size(40, 37);
            this.button260.TabIndex = 40;
            this.button260.UseVisualStyleBackColor = true;
            // 
            // button261
            // 
            this.button261.Location = new System.Drawing.Point(420, 149);
            this.button261.Name = "button261";
            this.button261.Size = new System.Drawing.Size(40, 37);
            this.button261.TabIndex = 39;
            this.button261.UseVisualStyleBackColor = true;
            // 
            // button262
            // 
            this.button262.Location = new System.Drawing.Point(374, 149);
            this.button262.Name = "button262";
            this.button262.Size = new System.Drawing.Size(40, 37);
            this.button262.TabIndex = 38;
            this.button262.UseVisualStyleBackColor = true;
            // 
            // button263
            // 
            this.button263.Location = new System.Drawing.Point(328, 149);
            this.button263.Name = "button263";
            this.button263.Size = new System.Drawing.Size(40, 37);
            this.button263.TabIndex = 37;
            this.button263.UseVisualStyleBackColor = true;
            // 
            // button264
            // 
            this.button264.Location = new System.Drawing.Point(282, 148);
            this.button264.Name = "button264";
            this.button264.Size = new System.Drawing.Size(40, 37);
            this.button264.TabIndex = 36;
            this.button264.UseVisualStyleBackColor = true;
            // 
            // button265
            // 
            this.button265.Location = new System.Drawing.Point(236, 149);
            this.button265.Name = "button265";
            this.button265.Size = new System.Drawing.Size(40, 37);
            this.button265.TabIndex = 35;
            this.button265.UseVisualStyleBackColor = true;
            // 
            // button266
            // 
            this.button266.Location = new System.Drawing.Point(190, 149);
            this.button266.Name = "button266";
            this.button266.Size = new System.Drawing.Size(40, 37);
            this.button266.TabIndex = 34;
            this.button266.UseVisualStyleBackColor = true;
            // 
            // button267
            // 
            this.button267.Location = new System.Drawing.Point(144, 148);
            this.button267.Name = "button267";
            this.button267.Size = new System.Drawing.Size(40, 37);
            this.button267.TabIndex = 33;
            this.button267.UseVisualStyleBackColor = true;
            // 
            // button268
            // 
            this.button268.Location = new System.Drawing.Point(98, 149);
            this.button268.Name = "button268";
            this.button268.Size = new System.Drawing.Size(40, 37);
            this.button268.TabIndex = 32;
            this.button268.UseVisualStyleBackColor = true;
            // 
            // button269
            // 
            this.button269.Location = new System.Drawing.Point(52, 149);
            this.button269.Name = "button269";
            this.button269.Size = new System.Drawing.Size(40, 37);
            this.button269.TabIndex = 31;
            this.button269.UseVisualStyleBackColor = true;
            // 
            // button270
            // 
            this.button270.Location = new System.Drawing.Point(6, 148);
            this.button270.Name = "button270";
            this.button270.Size = new System.Drawing.Size(40, 37);
            this.button270.TabIndex = 30;
            this.button270.UseVisualStyleBackColor = true;
            // 
            // button271
            // 
            this.button271.Location = new System.Drawing.Point(421, 105);
            this.button271.Name = "button271";
            this.button271.Size = new System.Drawing.Size(40, 37);
            this.button271.TabIndex = 29;
            this.button271.UseVisualStyleBackColor = true;
            // 
            // button272
            // 
            this.button272.Location = new System.Drawing.Point(374, 105);
            this.button272.Name = "button272";
            this.button272.Size = new System.Drawing.Size(40, 37);
            this.button272.TabIndex = 28;
            this.button272.UseVisualStyleBackColor = true;
            // 
            // button273
            // 
            this.button273.Location = new System.Drawing.Point(328, 105);
            this.button273.Name = "button273";
            this.button273.Size = new System.Drawing.Size(40, 37);
            this.button273.TabIndex = 27;
            this.button273.UseVisualStyleBackColor = true;
            // 
            // button274
            // 
            this.button274.Location = new System.Drawing.Point(282, 105);
            this.button274.Name = "button274";
            this.button274.Size = new System.Drawing.Size(40, 37);
            this.button274.TabIndex = 26;
            this.button274.UseVisualStyleBackColor = true;
            // 
            // button275
            // 
            this.button275.Location = new System.Drawing.Point(236, 105);
            this.button275.Name = "button275";
            this.button275.Size = new System.Drawing.Size(40, 37);
            this.button275.TabIndex = 25;
            this.button275.UseVisualStyleBackColor = true;
            // 
            // button276
            // 
            this.button276.Location = new System.Drawing.Point(190, 105);
            this.button276.Name = "button276";
            this.button276.Size = new System.Drawing.Size(40, 37);
            this.button276.TabIndex = 24;
            this.button276.UseVisualStyleBackColor = true;
            // 
            // button277
            // 
            this.button277.Location = new System.Drawing.Point(144, 105);
            this.button277.Name = "button277";
            this.button277.Size = new System.Drawing.Size(40, 37);
            this.button277.TabIndex = 23;
            this.button277.UseVisualStyleBackColor = true;
            // 
            // button278
            // 
            this.button278.Location = new System.Drawing.Point(98, 105);
            this.button278.Name = "button278";
            this.button278.Size = new System.Drawing.Size(40, 37);
            this.button278.TabIndex = 22;
            this.button278.UseVisualStyleBackColor = true;
            // 
            // button279
            // 
            this.button279.Location = new System.Drawing.Point(52, 105);
            this.button279.Name = "button279";
            this.button279.Size = new System.Drawing.Size(40, 37);
            this.button279.TabIndex = 21;
            this.button279.UseVisualStyleBackColor = true;
            // 
            // button280
            // 
            this.button280.Location = new System.Drawing.Point(6, 105);
            this.button280.Name = "button280";
            this.button280.Size = new System.Drawing.Size(40, 37);
            this.button280.TabIndex = 20;
            this.button280.UseVisualStyleBackColor = true;
            // 
            // button281
            // 
            this.button281.Location = new System.Drawing.Point(420, 62);
            this.button281.Name = "button281";
            this.button281.Size = new System.Drawing.Size(40, 37);
            this.button281.TabIndex = 19;
            this.button281.UseVisualStyleBackColor = true;
            // 
            // button282
            // 
            this.button282.Location = new System.Drawing.Point(374, 62);
            this.button282.Name = "button282";
            this.button282.Size = new System.Drawing.Size(40, 37);
            this.button282.TabIndex = 18;
            this.button282.UseVisualStyleBackColor = true;
            // 
            // button283
            // 
            this.button283.Location = new System.Drawing.Point(328, 62);
            this.button283.Name = "button283";
            this.button283.Size = new System.Drawing.Size(40, 37);
            this.button283.TabIndex = 17;
            this.button283.UseVisualStyleBackColor = true;
            // 
            // button284
            // 
            this.button284.Location = new System.Drawing.Point(282, 62);
            this.button284.Name = "button284";
            this.button284.Size = new System.Drawing.Size(40, 37);
            this.button284.TabIndex = 16;
            this.button284.UseVisualStyleBackColor = true;
            // 
            // button285
            // 
            this.button285.Location = new System.Drawing.Point(236, 62);
            this.button285.Name = "button285";
            this.button285.Size = new System.Drawing.Size(40, 37);
            this.button285.TabIndex = 15;
            this.button285.UseVisualStyleBackColor = true;
            // 
            // button286
            // 
            this.button286.Location = new System.Drawing.Point(190, 62);
            this.button286.Name = "button286";
            this.button286.Size = new System.Drawing.Size(40, 37);
            this.button286.TabIndex = 14;
            this.button286.UseVisualStyleBackColor = true;
            // 
            // button287
            // 
            this.button287.Location = new System.Drawing.Point(144, 62);
            this.button287.Name = "button287";
            this.button287.Size = new System.Drawing.Size(40, 37);
            this.button287.TabIndex = 13;
            this.button287.UseVisualStyleBackColor = true;
            // 
            // button288
            // 
            this.button288.Location = new System.Drawing.Point(98, 62);
            this.button288.Name = "button288";
            this.button288.Size = new System.Drawing.Size(40, 37);
            this.button288.TabIndex = 12;
            this.button288.UseVisualStyleBackColor = true;
            // 
            // button289
            // 
            this.button289.Location = new System.Drawing.Point(52, 62);
            this.button289.Name = "button289";
            this.button289.Size = new System.Drawing.Size(40, 37);
            this.button289.TabIndex = 11;
            this.button289.UseVisualStyleBackColor = true;
            // 
            // button290
            // 
            this.button290.Location = new System.Drawing.Point(6, 62);
            this.button290.Name = "button290";
            this.button290.Size = new System.Drawing.Size(40, 37);
            this.button290.TabIndex = 10;
            this.button290.UseVisualStyleBackColor = true;
            // 
            // button291
            // 
            this.button291.Location = new System.Drawing.Point(420, 19);
            this.button291.Name = "button291";
            this.button291.Size = new System.Drawing.Size(40, 37);
            this.button291.TabIndex = 9;
            this.button291.UseVisualStyleBackColor = true;
            // 
            // button292
            // 
            this.button292.Location = new System.Drawing.Point(374, 19);
            this.button292.Name = "button292";
            this.button292.Size = new System.Drawing.Size(40, 37);
            this.button292.TabIndex = 8;
            this.button292.UseVisualStyleBackColor = true;
            // 
            // button293
            // 
            this.button293.Location = new System.Drawing.Point(328, 19);
            this.button293.Name = "button293";
            this.button293.Size = new System.Drawing.Size(40, 37);
            this.button293.TabIndex = 7;
            this.button293.UseVisualStyleBackColor = true;
            // 
            // button294
            // 
            this.button294.Location = new System.Drawing.Point(282, 19);
            this.button294.Name = "button294";
            this.button294.Size = new System.Drawing.Size(40, 37);
            this.button294.TabIndex = 6;
            this.button294.UseVisualStyleBackColor = true;
            // 
            // button295
            // 
            this.button295.Location = new System.Drawing.Point(236, 19);
            this.button295.Name = "button295";
            this.button295.Size = new System.Drawing.Size(40, 37);
            this.button295.TabIndex = 5;
            this.button295.UseVisualStyleBackColor = true;
            // 
            // button296
            // 
            this.button296.Location = new System.Drawing.Point(190, 19);
            this.button296.Name = "button296";
            this.button296.Size = new System.Drawing.Size(40, 37);
            this.button296.TabIndex = 4;
            this.button296.UseVisualStyleBackColor = true;
            // 
            // button297
            // 
            this.button297.Location = new System.Drawing.Point(144, 19);
            this.button297.Name = "button297";
            this.button297.Size = new System.Drawing.Size(40, 37);
            this.button297.TabIndex = 3;
            this.button297.UseVisualStyleBackColor = true;
            // 
            // button298
            // 
            this.button298.Location = new System.Drawing.Point(98, 19);
            this.button298.Name = "button298";
            this.button298.Size = new System.Drawing.Size(40, 37);
            this.button298.TabIndex = 2;
            this.button298.UseVisualStyleBackColor = true;
            // 
            // button299
            // 
            this.button299.Location = new System.Drawing.Point(52, 19);
            this.button299.Name = "button299";
            this.button299.Size = new System.Drawing.Size(40, 37);
            this.button299.TabIndex = 1;
            this.button299.UseVisualStyleBackColor = true;
            // 
            // button300
            // 
            this.button300.Location = new System.Drawing.Point(6, 19);
            this.button300.Name = "button300";
            this.button300.Size = new System.Drawing.Size(40, 37);
            this.button300.TabIndex = 0;
            this.button300.UseVisualStyleBackColor = true;
            // 
            // player2PublicGridGroupBox
            // 
            this.player2PublicGridGroupBox.Controls.Add(this.button301);
            this.player2PublicGridGroupBox.Controls.Add(this.button302);
            this.player2PublicGridGroupBox.Controls.Add(this.button303);
            this.player2PublicGridGroupBox.Controls.Add(this.button304);
            this.player2PublicGridGroupBox.Controls.Add(this.button305);
            this.player2PublicGridGroupBox.Controls.Add(this.button306);
            this.player2PublicGridGroupBox.Controls.Add(this.button307);
            this.player2PublicGridGroupBox.Controls.Add(this.button308);
            this.player2PublicGridGroupBox.Controls.Add(this.button309);
            this.player2PublicGridGroupBox.Controls.Add(this.button310);
            this.player2PublicGridGroupBox.Controls.Add(this.button311);
            this.player2PublicGridGroupBox.Controls.Add(this.button312);
            this.player2PublicGridGroupBox.Controls.Add(this.button313);
            this.player2PublicGridGroupBox.Controls.Add(this.button314);
            this.player2PublicGridGroupBox.Controls.Add(this.button315);
            this.player2PublicGridGroupBox.Controls.Add(this.button316);
            this.player2PublicGridGroupBox.Controls.Add(this.button317);
            this.player2PublicGridGroupBox.Controls.Add(this.button318);
            this.player2PublicGridGroupBox.Controls.Add(this.button319);
            this.player2PublicGridGroupBox.Controls.Add(this.button320);
            this.player2PublicGridGroupBox.Controls.Add(this.button321);
            this.player2PublicGridGroupBox.Controls.Add(this.button322);
            this.player2PublicGridGroupBox.Controls.Add(this.button323);
            this.player2PublicGridGroupBox.Controls.Add(this.button324);
            this.player2PublicGridGroupBox.Controls.Add(this.button325);
            this.player2PublicGridGroupBox.Controls.Add(this.button326);
            this.player2PublicGridGroupBox.Controls.Add(this.button327);
            this.player2PublicGridGroupBox.Controls.Add(this.button328);
            this.player2PublicGridGroupBox.Controls.Add(this.button329);
            this.player2PublicGridGroupBox.Controls.Add(this.button330);
            this.player2PublicGridGroupBox.Controls.Add(this.button331);
            this.player2PublicGridGroupBox.Controls.Add(this.button332);
            this.player2PublicGridGroupBox.Controls.Add(this.button333);
            this.player2PublicGridGroupBox.Controls.Add(this.button334);
            this.player2PublicGridGroupBox.Controls.Add(this.button335);
            this.player2PublicGridGroupBox.Controls.Add(this.button336);
            this.player2PublicGridGroupBox.Controls.Add(this.button337);
            this.player2PublicGridGroupBox.Controls.Add(this.button338);
            this.player2PublicGridGroupBox.Controls.Add(this.button339);
            this.player2PublicGridGroupBox.Controls.Add(this.button340);
            this.player2PublicGridGroupBox.Controls.Add(this.button341);
            this.player2PublicGridGroupBox.Controls.Add(this.button342);
            this.player2PublicGridGroupBox.Controls.Add(this.button343);
            this.player2PublicGridGroupBox.Controls.Add(this.button344);
            this.player2PublicGridGroupBox.Controls.Add(this.button345);
            this.player2PublicGridGroupBox.Controls.Add(this.button346);
            this.player2PublicGridGroupBox.Controls.Add(this.button347);
            this.player2PublicGridGroupBox.Controls.Add(this.button348);
            this.player2PublicGridGroupBox.Controls.Add(this.button349);
            this.player2PublicGridGroupBox.Controls.Add(this.button350);
            this.player2PublicGridGroupBox.Controls.Add(this.button351);
            this.player2PublicGridGroupBox.Controls.Add(this.button352);
            this.player2PublicGridGroupBox.Controls.Add(this.button353);
            this.player2PublicGridGroupBox.Controls.Add(this.button354);
            this.player2PublicGridGroupBox.Controls.Add(this.button355);
            this.player2PublicGridGroupBox.Controls.Add(this.button356);
            this.player2PublicGridGroupBox.Controls.Add(this.button357);
            this.player2PublicGridGroupBox.Controls.Add(this.button358);
            this.player2PublicGridGroupBox.Controls.Add(this.button359);
            this.player2PublicGridGroupBox.Controls.Add(this.button360);
            this.player2PublicGridGroupBox.Controls.Add(this.button361);
            this.player2PublicGridGroupBox.Controls.Add(this.button362);
            this.player2PublicGridGroupBox.Controls.Add(this.button363);
            this.player2PublicGridGroupBox.Controls.Add(this.button364);
            this.player2PublicGridGroupBox.Controls.Add(this.button365);
            this.player2PublicGridGroupBox.Controls.Add(this.button366);
            this.player2PublicGridGroupBox.Controls.Add(this.button367);
            this.player2PublicGridGroupBox.Controls.Add(this.button368);
            this.player2PublicGridGroupBox.Controls.Add(this.button369);
            this.player2PublicGridGroupBox.Controls.Add(this.button370);
            this.player2PublicGridGroupBox.Controls.Add(this.button371);
            this.player2PublicGridGroupBox.Controls.Add(this.button372);
            this.player2PublicGridGroupBox.Controls.Add(this.button373);
            this.player2PublicGridGroupBox.Controls.Add(this.button374);
            this.player2PublicGridGroupBox.Controls.Add(this.button375);
            this.player2PublicGridGroupBox.Controls.Add(this.button376);
            this.player2PublicGridGroupBox.Controls.Add(this.button377);
            this.player2PublicGridGroupBox.Controls.Add(this.button378);
            this.player2PublicGridGroupBox.Controls.Add(this.button379);
            this.player2PublicGridGroupBox.Controls.Add(this.button380);
            this.player2PublicGridGroupBox.Controls.Add(this.button381);
            this.player2PublicGridGroupBox.Controls.Add(this.button382);
            this.player2PublicGridGroupBox.Controls.Add(this.button383);
            this.player2PublicGridGroupBox.Controls.Add(this.button384);
            this.player2PublicGridGroupBox.Controls.Add(this.button385);
            this.player2PublicGridGroupBox.Controls.Add(this.button386);
            this.player2PublicGridGroupBox.Controls.Add(this.button387);
            this.player2PublicGridGroupBox.Controls.Add(this.button388);
            this.player2PublicGridGroupBox.Controls.Add(this.button389);
            this.player2PublicGridGroupBox.Controls.Add(this.button390);
            this.player2PublicGridGroupBox.Controls.Add(this.button391);
            this.player2PublicGridGroupBox.Controls.Add(this.button392);
            this.player2PublicGridGroupBox.Controls.Add(this.button393);
            this.player2PublicGridGroupBox.Controls.Add(this.button394);
            this.player2PublicGridGroupBox.Controls.Add(this.button395);
            this.player2PublicGridGroupBox.Controls.Add(this.button396);
            this.player2PublicGridGroupBox.Controls.Add(this.button397);
            this.player2PublicGridGroupBox.Controls.Add(this.button398);
            this.player2PublicGridGroupBox.Controls.Add(this.button399);
            this.player2PublicGridGroupBox.Controls.Add(this.button400);
            this.player2PublicGridGroupBox.Location = new System.Drawing.Point(0, 0);
            this.player2PublicGridGroupBox.Name = "player2PublicGridGroupBox";
            this.player2PublicGridGroupBox.Size = new System.Drawing.Size(467, 451);
            this.player2PublicGridGroupBox.TabIndex = 102;
            this.player2PublicGridGroupBox.TabStop = false;
            this.player2PublicGridGroupBox.Text = "Player 2\'s Turn";
            this.player2PublicGridGroupBox.Visible = false;
            // 
            // button301
            // 
            this.button301.Location = new System.Drawing.Point(420, 406);
            this.button301.Name = "button301";
            this.button301.Size = new System.Drawing.Size(40, 37);
            this.button301.TabIndex = 99;
            this.button301.UseVisualStyleBackColor = true;
            // 
            // button302
            // 
            this.button302.Location = new System.Drawing.Point(374, 406);
            this.button302.Name = "button302";
            this.button302.Size = new System.Drawing.Size(40, 37);
            this.button302.TabIndex = 98;
            this.button302.UseVisualStyleBackColor = true;
            // 
            // button303
            // 
            this.button303.Location = new System.Drawing.Point(328, 406);
            this.button303.Name = "button303";
            this.button303.Size = new System.Drawing.Size(40, 37);
            this.button303.TabIndex = 97;
            this.button303.UseVisualStyleBackColor = true;
            // 
            // button304
            // 
            this.button304.Location = new System.Drawing.Point(282, 406);
            this.button304.Name = "button304";
            this.button304.Size = new System.Drawing.Size(40, 37);
            this.button304.TabIndex = 96;
            this.button304.UseVisualStyleBackColor = true;
            // 
            // button305
            // 
            this.button305.Location = new System.Drawing.Point(236, 406);
            this.button305.Name = "button305";
            this.button305.Size = new System.Drawing.Size(40, 37);
            this.button305.TabIndex = 95;
            this.button305.UseVisualStyleBackColor = true;
            // 
            // button306
            // 
            this.button306.Location = new System.Drawing.Point(190, 406);
            this.button306.Name = "button306";
            this.button306.Size = new System.Drawing.Size(40, 37);
            this.button306.TabIndex = 94;
            this.button306.UseVisualStyleBackColor = true;
            // 
            // button307
            // 
            this.button307.Location = new System.Drawing.Point(144, 406);
            this.button307.Name = "button307";
            this.button307.Size = new System.Drawing.Size(40, 37);
            this.button307.TabIndex = 93;
            this.button307.UseVisualStyleBackColor = true;
            // 
            // button308
            // 
            this.button308.Location = new System.Drawing.Point(98, 406);
            this.button308.Name = "button308";
            this.button308.Size = new System.Drawing.Size(40, 37);
            this.button308.TabIndex = 92;
            this.button308.UseVisualStyleBackColor = true;
            // 
            // button309
            // 
            this.button309.Location = new System.Drawing.Point(52, 406);
            this.button309.Name = "button309";
            this.button309.Size = new System.Drawing.Size(40, 37);
            this.button309.TabIndex = 91;
            this.button309.UseVisualStyleBackColor = true;
            // 
            // button310
            // 
            this.button310.Location = new System.Drawing.Point(6, 406);
            this.button310.Name = "button310";
            this.button310.Size = new System.Drawing.Size(40, 37);
            this.button310.TabIndex = 90;
            this.button310.UseVisualStyleBackColor = true;
            // 
            // button311
            // 
            this.button311.Location = new System.Drawing.Point(420, 363);
            this.button311.Name = "button311";
            this.button311.Size = new System.Drawing.Size(40, 37);
            this.button311.TabIndex = 89;
            this.button311.UseVisualStyleBackColor = true;
            // 
            // button312
            // 
            this.button312.Location = new System.Drawing.Point(374, 363);
            this.button312.Name = "button312";
            this.button312.Size = new System.Drawing.Size(40, 37);
            this.button312.TabIndex = 88;
            this.button312.UseVisualStyleBackColor = true;
            // 
            // button313
            // 
            this.button313.Location = new System.Drawing.Point(328, 363);
            this.button313.Name = "button313";
            this.button313.Size = new System.Drawing.Size(40, 37);
            this.button313.TabIndex = 87;
            this.button313.UseVisualStyleBackColor = true;
            // 
            // button314
            // 
            this.button314.Location = new System.Drawing.Point(282, 363);
            this.button314.Name = "button314";
            this.button314.Size = new System.Drawing.Size(40, 37);
            this.button314.TabIndex = 86;
            this.button314.UseVisualStyleBackColor = true;
            // 
            // button315
            // 
            this.button315.Location = new System.Drawing.Point(236, 363);
            this.button315.Name = "button315";
            this.button315.Size = new System.Drawing.Size(40, 37);
            this.button315.TabIndex = 85;
            this.button315.UseVisualStyleBackColor = true;
            // 
            // button316
            // 
            this.button316.Location = new System.Drawing.Point(190, 363);
            this.button316.Name = "button316";
            this.button316.Size = new System.Drawing.Size(40, 37);
            this.button316.TabIndex = 84;
            this.button316.UseVisualStyleBackColor = true;
            // 
            // button317
            // 
            this.button317.Location = new System.Drawing.Point(144, 363);
            this.button317.Name = "button317";
            this.button317.Size = new System.Drawing.Size(40, 37);
            this.button317.TabIndex = 83;
            this.button317.UseVisualStyleBackColor = true;
            // 
            // button318
            // 
            this.button318.Location = new System.Drawing.Point(98, 363);
            this.button318.Name = "button318";
            this.button318.Size = new System.Drawing.Size(40, 37);
            this.button318.TabIndex = 82;
            this.button318.UseVisualStyleBackColor = true;
            // 
            // button319
            // 
            this.button319.Location = new System.Drawing.Point(52, 363);
            this.button319.Name = "button319";
            this.button319.Size = new System.Drawing.Size(40, 37);
            this.button319.TabIndex = 81;
            this.button319.UseVisualStyleBackColor = true;
            // 
            // button320
            // 
            this.button320.Location = new System.Drawing.Point(6, 363);
            this.button320.Name = "button320";
            this.button320.Size = new System.Drawing.Size(40, 37);
            this.button320.TabIndex = 80;
            this.button320.UseVisualStyleBackColor = true;
            // 
            // button321
            // 
            this.button321.Location = new System.Drawing.Point(420, 320);
            this.button321.Name = "button321";
            this.button321.Size = new System.Drawing.Size(40, 37);
            this.button321.TabIndex = 79;
            this.button321.UseVisualStyleBackColor = true;
            // 
            // button322
            // 
            this.button322.Location = new System.Drawing.Point(374, 320);
            this.button322.Name = "button322";
            this.button322.Size = new System.Drawing.Size(40, 37);
            this.button322.TabIndex = 78;
            this.button322.UseVisualStyleBackColor = true;
            // 
            // button323
            // 
            this.button323.Location = new System.Drawing.Point(328, 320);
            this.button323.Name = "button323";
            this.button323.Size = new System.Drawing.Size(40, 37);
            this.button323.TabIndex = 77;
            this.button323.UseVisualStyleBackColor = true;
            // 
            // button324
            // 
            this.button324.Location = new System.Drawing.Point(282, 320);
            this.button324.Name = "button324";
            this.button324.Size = new System.Drawing.Size(40, 37);
            this.button324.TabIndex = 76;
            this.button324.UseVisualStyleBackColor = true;
            // 
            // button325
            // 
            this.button325.Location = new System.Drawing.Point(236, 320);
            this.button325.Name = "button325";
            this.button325.Size = new System.Drawing.Size(40, 37);
            this.button325.TabIndex = 75;
            this.button325.UseVisualStyleBackColor = true;
            // 
            // button326
            // 
            this.button326.Location = new System.Drawing.Point(190, 320);
            this.button326.Name = "button326";
            this.button326.Size = new System.Drawing.Size(40, 37);
            this.button326.TabIndex = 74;
            this.button326.UseVisualStyleBackColor = true;
            // 
            // button327
            // 
            this.button327.Location = new System.Drawing.Point(144, 320);
            this.button327.Name = "button327";
            this.button327.Size = new System.Drawing.Size(40, 37);
            this.button327.TabIndex = 73;
            this.button327.UseVisualStyleBackColor = true;
            // 
            // button328
            // 
            this.button328.Location = new System.Drawing.Point(98, 320);
            this.button328.Name = "button328";
            this.button328.Size = new System.Drawing.Size(40, 37);
            this.button328.TabIndex = 72;
            this.button328.UseVisualStyleBackColor = true;
            // 
            // button329
            // 
            this.button329.Location = new System.Drawing.Point(52, 320);
            this.button329.Name = "button329";
            this.button329.Size = new System.Drawing.Size(40, 37);
            this.button329.TabIndex = 71;
            this.button329.UseVisualStyleBackColor = true;
            // 
            // button330
            // 
            this.button330.Location = new System.Drawing.Point(6, 320);
            this.button330.Name = "button330";
            this.button330.Size = new System.Drawing.Size(40, 37);
            this.button330.TabIndex = 70;
            this.button330.UseVisualStyleBackColor = true;
            // 
            // button331
            // 
            this.button331.Location = new System.Drawing.Point(420, 277);
            this.button331.Name = "button331";
            this.button331.Size = new System.Drawing.Size(40, 37);
            this.button331.TabIndex = 69;
            this.button331.UseVisualStyleBackColor = true;
            // 
            // button332
            // 
            this.button332.Location = new System.Drawing.Point(374, 277);
            this.button332.Name = "button332";
            this.button332.Size = new System.Drawing.Size(40, 37);
            this.button332.TabIndex = 68;
            this.button332.UseVisualStyleBackColor = true;
            // 
            // button333
            // 
            this.button333.Location = new System.Drawing.Point(328, 277);
            this.button333.Name = "button333";
            this.button333.Size = new System.Drawing.Size(40, 37);
            this.button333.TabIndex = 67;
            this.button333.UseVisualStyleBackColor = true;
            // 
            // button334
            // 
            this.button334.Location = new System.Drawing.Point(282, 277);
            this.button334.Name = "button334";
            this.button334.Size = new System.Drawing.Size(40, 37);
            this.button334.TabIndex = 66;
            this.button334.UseVisualStyleBackColor = true;
            // 
            // button335
            // 
            this.button335.Location = new System.Drawing.Point(236, 277);
            this.button335.Name = "button335";
            this.button335.Size = new System.Drawing.Size(40, 37);
            this.button335.TabIndex = 65;
            this.button335.UseVisualStyleBackColor = true;
            // 
            // button336
            // 
            this.button336.Location = new System.Drawing.Point(190, 277);
            this.button336.Name = "button336";
            this.button336.Size = new System.Drawing.Size(40, 37);
            this.button336.TabIndex = 64;
            this.button336.UseVisualStyleBackColor = true;
            // 
            // button337
            // 
            this.button337.Location = new System.Drawing.Point(144, 277);
            this.button337.Name = "button337";
            this.button337.Size = new System.Drawing.Size(40, 37);
            this.button337.TabIndex = 63;
            this.button337.UseVisualStyleBackColor = true;
            // 
            // button338
            // 
            this.button338.Location = new System.Drawing.Point(98, 277);
            this.button338.Name = "button338";
            this.button338.Size = new System.Drawing.Size(40, 37);
            this.button338.TabIndex = 62;
            this.button338.UseVisualStyleBackColor = true;
            // 
            // button339
            // 
            this.button339.Location = new System.Drawing.Point(52, 277);
            this.button339.Name = "button339";
            this.button339.Size = new System.Drawing.Size(40, 37);
            this.button339.TabIndex = 61;
            this.button339.UseVisualStyleBackColor = true;
            // 
            // button340
            // 
            this.button340.Location = new System.Drawing.Point(6, 277);
            this.button340.Name = "button340";
            this.button340.Size = new System.Drawing.Size(40, 37);
            this.button340.TabIndex = 60;
            this.button340.UseVisualStyleBackColor = true;
            // 
            // button341
            // 
            this.button341.Location = new System.Drawing.Point(420, 234);
            this.button341.Name = "button341";
            this.button341.Size = new System.Drawing.Size(40, 37);
            this.button341.TabIndex = 59;
            this.button341.UseVisualStyleBackColor = true;
            // 
            // button342
            // 
            this.button342.Location = new System.Drawing.Point(374, 234);
            this.button342.Name = "button342";
            this.button342.Size = new System.Drawing.Size(40, 37);
            this.button342.TabIndex = 58;
            this.button342.UseVisualStyleBackColor = true;
            // 
            // button343
            // 
            this.button343.Location = new System.Drawing.Point(328, 234);
            this.button343.Name = "button343";
            this.button343.Size = new System.Drawing.Size(40, 37);
            this.button343.TabIndex = 57;
            this.button343.UseVisualStyleBackColor = true;
            // 
            // button344
            // 
            this.button344.Location = new System.Drawing.Point(282, 234);
            this.button344.Name = "button344";
            this.button344.Size = new System.Drawing.Size(40, 37);
            this.button344.TabIndex = 56;
            this.button344.UseVisualStyleBackColor = true;
            // 
            // button345
            // 
            this.button345.Location = new System.Drawing.Point(236, 234);
            this.button345.Name = "button345";
            this.button345.Size = new System.Drawing.Size(40, 37);
            this.button345.TabIndex = 55;
            this.button345.UseVisualStyleBackColor = true;
            // 
            // button346
            // 
            this.button346.Location = new System.Drawing.Point(190, 234);
            this.button346.Name = "button346";
            this.button346.Size = new System.Drawing.Size(40, 37);
            this.button346.TabIndex = 54;
            this.button346.UseVisualStyleBackColor = true;
            // 
            // button347
            // 
            this.button347.Location = new System.Drawing.Point(144, 234);
            this.button347.Name = "button347";
            this.button347.Size = new System.Drawing.Size(40, 37);
            this.button347.TabIndex = 53;
            this.button347.UseVisualStyleBackColor = true;
            // 
            // button348
            // 
            this.button348.Location = new System.Drawing.Point(98, 234);
            this.button348.Name = "button348";
            this.button348.Size = new System.Drawing.Size(40, 37);
            this.button348.TabIndex = 52;
            this.button348.UseVisualStyleBackColor = true;
            // 
            // button349
            // 
            this.button349.Location = new System.Drawing.Point(52, 234);
            this.button349.Name = "button349";
            this.button349.Size = new System.Drawing.Size(40, 37);
            this.button349.TabIndex = 51;
            this.button349.UseVisualStyleBackColor = true;
            // 
            // button350
            // 
            this.button350.Location = new System.Drawing.Point(6, 234);
            this.button350.Name = "button350";
            this.button350.Size = new System.Drawing.Size(40, 37);
            this.button350.TabIndex = 50;
            this.button350.UseVisualStyleBackColor = true;
            // 
            // button351
            // 
            this.button351.Location = new System.Drawing.Point(420, 192);
            this.button351.Name = "button351";
            this.button351.Size = new System.Drawing.Size(40, 37);
            this.button351.TabIndex = 49;
            this.button351.UseVisualStyleBackColor = true;
            // 
            // button352
            // 
            this.button352.Location = new System.Drawing.Point(374, 191);
            this.button352.Name = "button352";
            this.button352.Size = new System.Drawing.Size(40, 37);
            this.button352.TabIndex = 48;
            this.button352.UseVisualStyleBackColor = true;
            // 
            // button353
            // 
            this.button353.Location = new System.Drawing.Point(328, 191);
            this.button353.Name = "button353";
            this.button353.Size = new System.Drawing.Size(40, 37);
            this.button353.TabIndex = 47;
            this.button353.UseVisualStyleBackColor = true;
            // 
            // button354
            // 
            this.button354.Location = new System.Drawing.Point(282, 191);
            this.button354.Name = "button354";
            this.button354.Size = new System.Drawing.Size(40, 37);
            this.button354.TabIndex = 46;
            this.button354.UseVisualStyleBackColor = true;
            // 
            // button355
            // 
            this.button355.Location = new System.Drawing.Point(236, 191);
            this.button355.Name = "button355";
            this.button355.Size = new System.Drawing.Size(40, 37);
            this.button355.TabIndex = 45;
            this.button355.UseVisualStyleBackColor = true;
            // 
            // button356
            // 
            this.button356.Location = new System.Drawing.Point(190, 191);
            this.button356.Name = "button356";
            this.button356.Size = new System.Drawing.Size(40, 37);
            this.button356.TabIndex = 44;
            this.button356.UseVisualStyleBackColor = true;
            // 
            // button357
            // 
            this.button357.Location = new System.Drawing.Point(144, 191);
            this.button357.Name = "button357";
            this.button357.Size = new System.Drawing.Size(40, 37);
            this.button357.TabIndex = 43;
            this.button357.UseVisualStyleBackColor = true;
            // 
            // button358
            // 
            this.button358.Location = new System.Drawing.Point(98, 191);
            this.button358.Name = "button358";
            this.button358.Size = new System.Drawing.Size(40, 37);
            this.button358.TabIndex = 42;
            this.button358.UseVisualStyleBackColor = true;
            // 
            // button359
            // 
            this.button359.Location = new System.Drawing.Point(52, 191);
            this.button359.Name = "button359";
            this.button359.Size = new System.Drawing.Size(40, 37);
            this.button359.TabIndex = 41;
            this.button359.UseVisualStyleBackColor = true;
            // 
            // button360
            // 
            this.button360.Location = new System.Drawing.Point(6, 191);
            this.button360.Name = "button360";
            this.button360.Size = new System.Drawing.Size(40, 37);
            this.button360.TabIndex = 40;
            this.button360.UseVisualStyleBackColor = true;
            // 
            // button361
            // 
            this.button361.Location = new System.Drawing.Point(420, 149);
            this.button361.Name = "button361";
            this.button361.Size = new System.Drawing.Size(40, 37);
            this.button361.TabIndex = 39;
            this.button361.UseVisualStyleBackColor = true;
            // 
            // button362
            // 
            this.button362.Location = new System.Drawing.Point(374, 149);
            this.button362.Name = "button362";
            this.button362.Size = new System.Drawing.Size(40, 37);
            this.button362.TabIndex = 38;
            this.button362.UseVisualStyleBackColor = true;
            // 
            // button363
            // 
            this.button363.Location = new System.Drawing.Point(328, 149);
            this.button363.Name = "button363";
            this.button363.Size = new System.Drawing.Size(40, 37);
            this.button363.TabIndex = 37;
            this.button363.UseVisualStyleBackColor = true;
            // 
            // button364
            // 
            this.button364.Location = new System.Drawing.Point(282, 148);
            this.button364.Name = "button364";
            this.button364.Size = new System.Drawing.Size(40, 37);
            this.button364.TabIndex = 36;
            this.button364.UseVisualStyleBackColor = true;
            // 
            // button365
            // 
            this.button365.Location = new System.Drawing.Point(236, 149);
            this.button365.Name = "button365";
            this.button365.Size = new System.Drawing.Size(40, 37);
            this.button365.TabIndex = 35;
            this.button365.UseVisualStyleBackColor = true;
            // 
            // button366
            // 
            this.button366.Location = new System.Drawing.Point(190, 149);
            this.button366.Name = "button366";
            this.button366.Size = new System.Drawing.Size(40, 37);
            this.button366.TabIndex = 34;
            this.button366.UseVisualStyleBackColor = true;
            // 
            // button367
            // 
            this.button367.Location = new System.Drawing.Point(144, 148);
            this.button367.Name = "button367";
            this.button367.Size = new System.Drawing.Size(40, 37);
            this.button367.TabIndex = 33;
            this.button367.UseVisualStyleBackColor = true;
            // 
            // button368
            // 
            this.button368.Location = new System.Drawing.Point(98, 149);
            this.button368.Name = "button368";
            this.button368.Size = new System.Drawing.Size(40, 37);
            this.button368.TabIndex = 32;
            this.button368.UseVisualStyleBackColor = true;
            // 
            // button369
            // 
            this.button369.Location = new System.Drawing.Point(52, 149);
            this.button369.Name = "button369";
            this.button369.Size = new System.Drawing.Size(40, 37);
            this.button369.TabIndex = 31;
            this.button369.UseVisualStyleBackColor = true;
            // 
            // button370
            // 
            this.button370.Location = new System.Drawing.Point(6, 148);
            this.button370.Name = "button370";
            this.button370.Size = new System.Drawing.Size(40, 37);
            this.button370.TabIndex = 30;
            this.button370.UseVisualStyleBackColor = true;
            // 
            // button371
            // 
            this.button371.Location = new System.Drawing.Point(421, 105);
            this.button371.Name = "button371";
            this.button371.Size = new System.Drawing.Size(40, 37);
            this.button371.TabIndex = 29;
            this.button371.UseVisualStyleBackColor = true;
            // 
            // button372
            // 
            this.button372.Location = new System.Drawing.Point(374, 105);
            this.button372.Name = "button372";
            this.button372.Size = new System.Drawing.Size(40, 37);
            this.button372.TabIndex = 28;
            this.button372.UseVisualStyleBackColor = true;
            // 
            // button373
            // 
            this.button373.Location = new System.Drawing.Point(328, 105);
            this.button373.Name = "button373";
            this.button373.Size = new System.Drawing.Size(40, 37);
            this.button373.TabIndex = 27;
            this.button373.UseVisualStyleBackColor = true;
            // 
            // button374
            // 
            this.button374.Location = new System.Drawing.Point(282, 105);
            this.button374.Name = "button374";
            this.button374.Size = new System.Drawing.Size(40, 37);
            this.button374.TabIndex = 26;
            this.button374.UseVisualStyleBackColor = true;
            // 
            // button375
            // 
            this.button375.Location = new System.Drawing.Point(236, 105);
            this.button375.Name = "button375";
            this.button375.Size = new System.Drawing.Size(40, 37);
            this.button375.TabIndex = 25;
            this.button375.UseVisualStyleBackColor = true;
            // 
            // button376
            // 
            this.button376.Location = new System.Drawing.Point(190, 105);
            this.button376.Name = "button376";
            this.button376.Size = new System.Drawing.Size(40, 37);
            this.button376.TabIndex = 24;
            this.button376.UseVisualStyleBackColor = true;
            // 
            // button377
            // 
            this.button377.Location = new System.Drawing.Point(144, 105);
            this.button377.Name = "button377";
            this.button377.Size = new System.Drawing.Size(40, 37);
            this.button377.TabIndex = 23;
            this.button377.UseVisualStyleBackColor = true;
            // 
            // button378
            // 
            this.button378.Location = new System.Drawing.Point(98, 105);
            this.button378.Name = "button378";
            this.button378.Size = new System.Drawing.Size(40, 37);
            this.button378.TabIndex = 22;
            this.button378.UseVisualStyleBackColor = true;
            // 
            // button379
            // 
            this.button379.Location = new System.Drawing.Point(52, 105);
            this.button379.Name = "button379";
            this.button379.Size = new System.Drawing.Size(40, 37);
            this.button379.TabIndex = 21;
            this.button379.UseVisualStyleBackColor = true;
            // 
            // button380
            // 
            this.button380.Location = new System.Drawing.Point(6, 105);
            this.button380.Name = "button380";
            this.button380.Size = new System.Drawing.Size(40, 37);
            this.button380.TabIndex = 20;
            this.button380.UseVisualStyleBackColor = true;
            // 
            // button381
            // 
            this.button381.Location = new System.Drawing.Point(420, 62);
            this.button381.Name = "button381";
            this.button381.Size = new System.Drawing.Size(40, 37);
            this.button381.TabIndex = 19;
            this.button381.UseVisualStyleBackColor = true;
            // 
            // button382
            // 
            this.button382.Location = new System.Drawing.Point(374, 62);
            this.button382.Name = "button382";
            this.button382.Size = new System.Drawing.Size(40, 37);
            this.button382.TabIndex = 18;
            this.button382.UseVisualStyleBackColor = true;
            // 
            // button383
            // 
            this.button383.Location = new System.Drawing.Point(328, 62);
            this.button383.Name = "button383";
            this.button383.Size = new System.Drawing.Size(40, 37);
            this.button383.TabIndex = 17;
            this.button383.UseVisualStyleBackColor = true;
            // 
            // button384
            // 
            this.button384.Location = new System.Drawing.Point(282, 62);
            this.button384.Name = "button384";
            this.button384.Size = new System.Drawing.Size(40, 37);
            this.button384.TabIndex = 16;
            this.button384.UseVisualStyleBackColor = true;
            // 
            // button385
            // 
            this.button385.Location = new System.Drawing.Point(236, 62);
            this.button385.Name = "button385";
            this.button385.Size = new System.Drawing.Size(40, 37);
            this.button385.TabIndex = 15;
            this.button385.UseVisualStyleBackColor = true;
            // 
            // button386
            // 
            this.button386.Location = new System.Drawing.Point(190, 62);
            this.button386.Name = "button386";
            this.button386.Size = new System.Drawing.Size(40, 37);
            this.button386.TabIndex = 14;
            this.button386.UseVisualStyleBackColor = true;
            // 
            // button387
            // 
            this.button387.Location = new System.Drawing.Point(144, 62);
            this.button387.Name = "button387";
            this.button387.Size = new System.Drawing.Size(40, 37);
            this.button387.TabIndex = 13;
            this.button387.UseVisualStyleBackColor = true;
            // 
            // button388
            // 
            this.button388.Location = new System.Drawing.Point(98, 62);
            this.button388.Name = "button388";
            this.button388.Size = new System.Drawing.Size(40, 37);
            this.button388.TabIndex = 12;
            this.button388.UseVisualStyleBackColor = true;
            // 
            // button389
            // 
            this.button389.Location = new System.Drawing.Point(52, 62);
            this.button389.Name = "button389";
            this.button389.Size = new System.Drawing.Size(40, 37);
            this.button389.TabIndex = 11;
            this.button389.UseVisualStyleBackColor = true;
            // 
            // button390
            // 
            this.button390.Location = new System.Drawing.Point(6, 62);
            this.button390.Name = "button390";
            this.button390.Size = new System.Drawing.Size(40, 37);
            this.button390.TabIndex = 10;
            this.button390.UseVisualStyleBackColor = true;
            // 
            // button391
            // 
            this.button391.Location = new System.Drawing.Point(420, 19);
            this.button391.Name = "button391";
            this.button391.Size = new System.Drawing.Size(40, 37);
            this.button391.TabIndex = 9;
            this.button391.UseVisualStyleBackColor = true;
            // 
            // button392
            // 
            this.button392.Location = new System.Drawing.Point(374, 19);
            this.button392.Name = "button392";
            this.button392.Size = new System.Drawing.Size(40, 37);
            this.button392.TabIndex = 8;
            this.button392.UseVisualStyleBackColor = true;
            // 
            // button393
            // 
            this.button393.Location = new System.Drawing.Point(328, 19);
            this.button393.Name = "button393";
            this.button393.Size = new System.Drawing.Size(40, 37);
            this.button393.TabIndex = 7;
            this.button393.UseVisualStyleBackColor = true;
            // 
            // button394
            // 
            this.button394.Location = new System.Drawing.Point(282, 19);
            this.button394.Name = "button394";
            this.button394.Size = new System.Drawing.Size(40, 37);
            this.button394.TabIndex = 6;
            this.button394.UseVisualStyleBackColor = true;
            // 
            // button395
            // 
            this.button395.Location = new System.Drawing.Point(236, 19);
            this.button395.Name = "button395";
            this.button395.Size = new System.Drawing.Size(40, 37);
            this.button395.TabIndex = 5;
            this.button395.UseVisualStyleBackColor = true;
            // 
            // button396
            // 
            this.button396.Location = new System.Drawing.Point(190, 19);
            this.button396.Name = "button396";
            this.button396.Size = new System.Drawing.Size(40, 37);
            this.button396.TabIndex = 4;
            this.button396.UseVisualStyleBackColor = true;
            // 
            // button397
            // 
            this.button397.Location = new System.Drawing.Point(144, 19);
            this.button397.Name = "button397";
            this.button397.Size = new System.Drawing.Size(40, 37);
            this.button397.TabIndex = 3;
            this.button397.UseVisualStyleBackColor = true;
            // 
            // button398
            // 
            this.button398.Location = new System.Drawing.Point(98, 19);
            this.button398.Name = "button398";
            this.button398.Size = new System.Drawing.Size(40, 37);
            this.button398.TabIndex = 2;
            this.button398.UseVisualStyleBackColor = true;
            // 
            // button399
            // 
            this.button399.Location = new System.Drawing.Point(52, 19);
            this.button399.Name = "button399";
            this.button399.Size = new System.Drawing.Size(40, 37);
            this.button399.TabIndex = 1;
            this.button399.UseVisualStyleBackColor = true;
            // 
            // button400
            // 
            this.button400.Location = new System.Drawing.Point(6, 19);
            this.button400.Name = "button400";
            this.button400.Size = new System.Drawing.Size(40, 37);
            this.button400.TabIndex = 0;
            this.button400.UseVisualStyleBackColor = true;
            // 
            // GameWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(641, 459);
            this.Controls.Add(this.player2SecretGridGroupBox);
            this.Controls.Add(this.debugLabel);
            this.Controls.Add(this.endTurnBtn);
            this.Controls.Add(this.newGameBtn);
            this.Controls.Add(this.player1SecretGridGroupBox);
            this.Name = "GameWindow";
            this.Text = "GameWindow";
            this.Load += new System.EventHandler(this.GameWindow_Load);
            this.player1SecretGridGroupBox.ResumeLayout(false);
            this.player2SecretGridGroupBox.ResumeLayout(false);
            this.player1PublicGridGroupBox.ResumeLayout(false);
            this.player2PublicGridGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox player1SecretGridGroupBox;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button newGameBtn;
        private System.Windows.Forms.Button endTurnBtn;
        private System.Windows.Forms.Label debugLabel;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.GroupBox player2SecretGridGroupBox;
        private System.Windows.Forms.Button button101;
        private System.Windows.Forms.Button button102;
        private System.Windows.Forms.Button button103;
        private System.Windows.Forms.Button button104;
        private System.Windows.Forms.Button button105;
        private System.Windows.Forms.Button button106;
        private System.Windows.Forms.Button button107;
        private System.Windows.Forms.Button button108;
        private System.Windows.Forms.Button button109;
        private System.Windows.Forms.Button button110;
        private System.Windows.Forms.Button button111;
        private System.Windows.Forms.Button button112;
        private System.Windows.Forms.Button button113;
        private System.Windows.Forms.Button button114;
        private System.Windows.Forms.Button button115;
        private System.Windows.Forms.Button button116;
        private System.Windows.Forms.Button button117;
        private System.Windows.Forms.Button button118;
        private System.Windows.Forms.Button button119;
        private System.Windows.Forms.Button button120;
        private System.Windows.Forms.Button button121;
        private System.Windows.Forms.Button button122;
        private System.Windows.Forms.Button button123;
        private System.Windows.Forms.Button button124;
        private System.Windows.Forms.Button button125;
        private System.Windows.Forms.Button button126;
        private System.Windows.Forms.Button button127;
        private System.Windows.Forms.Button button128;
        private System.Windows.Forms.Button button129;
        private System.Windows.Forms.Button button130;
        private System.Windows.Forms.Button button131;
        private System.Windows.Forms.Button button132;
        private System.Windows.Forms.Button button133;
        private System.Windows.Forms.Button button134;
        private System.Windows.Forms.Button button135;
        private System.Windows.Forms.Button button136;
        private System.Windows.Forms.Button button137;
        private System.Windows.Forms.Button button138;
        private System.Windows.Forms.Button button139;
        private System.Windows.Forms.Button button140;
        private System.Windows.Forms.Button button141;
        private System.Windows.Forms.Button button142;
        private System.Windows.Forms.Button button143;
        private System.Windows.Forms.Button button144;
        private System.Windows.Forms.Button button145;
        private System.Windows.Forms.Button button146;
        private System.Windows.Forms.Button button147;
        private System.Windows.Forms.Button button148;
        private System.Windows.Forms.Button button149;
        private System.Windows.Forms.Button button150;
        private System.Windows.Forms.Button button151;
        private System.Windows.Forms.Button button152;
        private System.Windows.Forms.Button button153;
        private System.Windows.Forms.Button button154;
        private System.Windows.Forms.Button button155;
        private System.Windows.Forms.Button button156;
        private System.Windows.Forms.Button button157;
        private System.Windows.Forms.Button button158;
        private System.Windows.Forms.Button button159;
        private System.Windows.Forms.Button button160;
        private System.Windows.Forms.Button button161;
        private System.Windows.Forms.Button button162;
        private System.Windows.Forms.Button button163;
        private System.Windows.Forms.Button button164;
        private System.Windows.Forms.Button button165;
        private System.Windows.Forms.Button button166;
        private System.Windows.Forms.Button button167;
        private System.Windows.Forms.Button button168;
        private System.Windows.Forms.Button button169;
        private System.Windows.Forms.Button button170;
        private System.Windows.Forms.Button button171;
        private System.Windows.Forms.Button button172;
        private System.Windows.Forms.Button button173;
        private System.Windows.Forms.Button button174;
        private System.Windows.Forms.Button button175;
        private System.Windows.Forms.Button button176;
        private System.Windows.Forms.Button button177;
        private System.Windows.Forms.Button button178;
        private System.Windows.Forms.Button button179;
        private System.Windows.Forms.Button button180;
        private System.Windows.Forms.Button button181;
        private System.Windows.Forms.Button button182;
        private System.Windows.Forms.Button button183;
        private System.Windows.Forms.Button button184;
        private System.Windows.Forms.Button button185;
        private System.Windows.Forms.Button button186;
        private System.Windows.Forms.Button button187;
        private System.Windows.Forms.Button button188;
        private System.Windows.Forms.Button button189;
        private System.Windows.Forms.Button button190;
        private System.Windows.Forms.Button button191;
        private System.Windows.Forms.Button button192;
        private System.Windows.Forms.Button button193;
        private System.Windows.Forms.Button button194;
        private System.Windows.Forms.Button button195;
        private System.Windows.Forms.Button button196;
        private System.Windows.Forms.Button button197;
        private System.Windows.Forms.Button button198;
        private System.Windows.Forms.Button button199;
        private System.Windows.Forms.Button button200;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Button button99;
        private System.Windows.Forms.Button button98;
        private System.Windows.Forms.Button button97;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.GroupBox player1PublicGridGroupBox;
        private System.Windows.Forms.GroupBox player2PublicGridGroupBox;
        private System.Windows.Forms.Button button301;
        private System.Windows.Forms.Button button302;
        private System.Windows.Forms.Button button303;
        private System.Windows.Forms.Button button304;
        private System.Windows.Forms.Button button305;
        private System.Windows.Forms.Button button306;
        private System.Windows.Forms.Button button307;
        private System.Windows.Forms.Button button308;
        private System.Windows.Forms.Button button309;
        private System.Windows.Forms.Button button310;
        private System.Windows.Forms.Button button311;
        private System.Windows.Forms.Button button312;
        private System.Windows.Forms.Button button313;
        private System.Windows.Forms.Button button314;
        private System.Windows.Forms.Button button315;
        private System.Windows.Forms.Button button316;
        private System.Windows.Forms.Button button317;
        private System.Windows.Forms.Button button318;
        private System.Windows.Forms.Button button319;
        private System.Windows.Forms.Button button320;
        private System.Windows.Forms.Button button321;
        private System.Windows.Forms.Button button322;
        private System.Windows.Forms.Button button323;
        private System.Windows.Forms.Button button324;
        private System.Windows.Forms.Button button325;
        private System.Windows.Forms.Button button326;
        private System.Windows.Forms.Button button327;
        private System.Windows.Forms.Button button328;
        private System.Windows.Forms.Button button329;
        private System.Windows.Forms.Button button330;
        private System.Windows.Forms.Button button331;
        private System.Windows.Forms.Button button332;
        private System.Windows.Forms.Button button333;
        private System.Windows.Forms.Button button334;
        private System.Windows.Forms.Button button335;
        private System.Windows.Forms.Button button336;
        private System.Windows.Forms.Button button337;
        private System.Windows.Forms.Button button338;
        private System.Windows.Forms.Button button339;
        private System.Windows.Forms.Button button340;
        private System.Windows.Forms.Button button341;
        private System.Windows.Forms.Button button342;
        private System.Windows.Forms.Button button343;
        private System.Windows.Forms.Button button344;
        private System.Windows.Forms.Button button345;
        private System.Windows.Forms.Button button346;
        private System.Windows.Forms.Button button347;
        private System.Windows.Forms.Button button348;
        private System.Windows.Forms.Button button349;
        private System.Windows.Forms.Button button350;
        private System.Windows.Forms.Button button351;
        private System.Windows.Forms.Button button352;
        private System.Windows.Forms.Button button353;
        private System.Windows.Forms.Button button354;
        private System.Windows.Forms.Button button355;
        private System.Windows.Forms.Button button356;
        private System.Windows.Forms.Button button357;
        private System.Windows.Forms.Button button358;
        private System.Windows.Forms.Button button359;
        private System.Windows.Forms.Button button360;
        private System.Windows.Forms.Button button361;
        private System.Windows.Forms.Button button362;
        private System.Windows.Forms.Button button363;
        private System.Windows.Forms.Button button364;
        private System.Windows.Forms.Button button365;
        private System.Windows.Forms.Button button366;
        private System.Windows.Forms.Button button367;
        private System.Windows.Forms.Button button368;
        private System.Windows.Forms.Button button369;
        private System.Windows.Forms.Button button370;
        private System.Windows.Forms.Button button371;
        private System.Windows.Forms.Button button372;
        private System.Windows.Forms.Button button373;
        private System.Windows.Forms.Button button374;
        private System.Windows.Forms.Button button375;
        private System.Windows.Forms.Button button376;
        private System.Windows.Forms.Button button377;
        private System.Windows.Forms.Button button378;
        private System.Windows.Forms.Button button379;
        private System.Windows.Forms.Button button380;
        private System.Windows.Forms.Button button381;
        private System.Windows.Forms.Button button382;
        private System.Windows.Forms.Button button383;
        private System.Windows.Forms.Button button384;
        private System.Windows.Forms.Button button385;
        private System.Windows.Forms.Button button386;
        private System.Windows.Forms.Button button387;
        private System.Windows.Forms.Button button388;
        private System.Windows.Forms.Button button389;
        private System.Windows.Forms.Button button390;
        private System.Windows.Forms.Button button391;
        private System.Windows.Forms.Button button392;
        private System.Windows.Forms.Button button393;
        private System.Windows.Forms.Button button394;
        private System.Windows.Forms.Button button395;
        private System.Windows.Forms.Button button396;
        private System.Windows.Forms.Button button397;
        private System.Windows.Forms.Button button398;
        private System.Windows.Forms.Button button399;
        private System.Windows.Forms.Button button400;
        private System.Windows.Forms.Button button201;
        private System.Windows.Forms.Button button202;
        private System.Windows.Forms.Button button203;
        private System.Windows.Forms.Button button204;
        private System.Windows.Forms.Button button205;
        private System.Windows.Forms.Button button206;
        private System.Windows.Forms.Button button207;
        private System.Windows.Forms.Button button208;
        private System.Windows.Forms.Button button209;
        private System.Windows.Forms.Button button210;
        private System.Windows.Forms.Button button211;
        private System.Windows.Forms.Button button212;
        private System.Windows.Forms.Button button213;
        private System.Windows.Forms.Button button214;
        private System.Windows.Forms.Button button215;
        private System.Windows.Forms.Button button216;
        private System.Windows.Forms.Button button217;
        private System.Windows.Forms.Button button218;
        private System.Windows.Forms.Button button219;
        private System.Windows.Forms.Button button220;
        private System.Windows.Forms.Button button221;
        private System.Windows.Forms.Button button222;
        private System.Windows.Forms.Button button223;
        private System.Windows.Forms.Button button224;
        private System.Windows.Forms.Button button225;
        private System.Windows.Forms.Button button226;
        private System.Windows.Forms.Button button227;
        private System.Windows.Forms.Button button228;
        private System.Windows.Forms.Button button229;
        private System.Windows.Forms.Button button230;
        private System.Windows.Forms.Button button231;
        private System.Windows.Forms.Button button232;
        private System.Windows.Forms.Button button233;
        private System.Windows.Forms.Button button234;
        private System.Windows.Forms.Button button235;
        private System.Windows.Forms.Button button236;
        private System.Windows.Forms.Button button237;
        private System.Windows.Forms.Button button238;
        private System.Windows.Forms.Button button239;
        private System.Windows.Forms.Button button240;
        private System.Windows.Forms.Button button241;
        private System.Windows.Forms.Button button242;
        private System.Windows.Forms.Button button243;
        private System.Windows.Forms.Button button244;
        private System.Windows.Forms.Button button245;
        private System.Windows.Forms.Button button246;
        private System.Windows.Forms.Button button247;
        private System.Windows.Forms.Button button248;
        private System.Windows.Forms.Button button249;
        private System.Windows.Forms.Button button250;
        private System.Windows.Forms.Button button251;
        private System.Windows.Forms.Button button252;
        private System.Windows.Forms.Button button253;
        private System.Windows.Forms.Button button254;
        private System.Windows.Forms.Button button255;
        private System.Windows.Forms.Button button256;
        private System.Windows.Forms.Button button257;
        private System.Windows.Forms.Button button258;
        private System.Windows.Forms.Button button259;
        private System.Windows.Forms.Button button260;
        private System.Windows.Forms.Button button261;
        private System.Windows.Forms.Button button262;
        private System.Windows.Forms.Button button263;
        private System.Windows.Forms.Button button264;
        private System.Windows.Forms.Button button265;
        private System.Windows.Forms.Button button266;
        private System.Windows.Forms.Button button267;
        private System.Windows.Forms.Button button268;
        private System.Windows.Forms.Button button269;
        private System.Windows.Forms.Button button270;
        private System.Windows.Forms.Button button271;
        private System.Windows.Forms.Button button272;
        private System.Windows.Forms.Button button273;
        private System.Windows.Forms.Button button274;
        private System.Windows.Forms.Button button275;
        private System.Windows.Forms.Button button276;
        private System.Windows.Forms.Button button277;
        private System.Windows.Forms.Button button278;
        private System.Windows.Forms.Button button279;
        private System.Windows.Forms.Button button280;
        private System.Windows.Forms.Button button281;
        private System.Windows.Forms.Button button282;
        private System.Windows.Forms.Button button283;
        private System.Windows.Forms.Button button284;
        private System.Windows.Forms.Button button285;
        private System.Windows.Forms.Button button286;
        private System.Windows.Forms.Button button287;
        private System.Windows.Forms.Button button288;
        private System.Windows.Forms.Button button289;
        private System.Windows.Forms.Button button290;
        private System.Windows.Forms.Button button291;
        private System.Windows.Forms.Button button292;
        private System.Windows.Forms.Button button293;
        private System.Windows.Forms.Button button294;
        private System.Windows.Forms.Button button295;
        private System.Windows.Forms.Button button296;
        private System.Windows.Forms.Button button297;
        private System.Windows.Forms.Button button298;
        private System.Windows.Forms.Button button299;
        private System.Windows.Forms.Button button300;
    }
}